import Link from "next/link";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 dark:from-gray-900 dark:via-black dark:to-purple-950">
      {/* Hero Section */}
      <main className="container mx-auto px-4 py-16 md:py-24">
        <div className="max-w-5xl mx-auto text-center">
          {/* Logo/Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-100 dark:bg-indigo-900/30 rounded-full mb-8">
            <span className="text-2xl">💡</span>
            <span className="text-sm font-semibold text-indigo-700 dark:text-indigo-300">
              AI-Powered Validation
            </span>
          </div>

          {/* Main Heading */}
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6">
            <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              VentureIQ
            </span>
          </h1>
          
          <p className="text-2xl md:text-3xl font-semibold text-gray-700 dark:text-gray-200 mb-6">
            Validate Your Business Ideas with AI
          </p>
          
          <p className="text-lg md:text-xl text-gray-600 dark:text-gray-400 mb-12 max-w-3xl mx-auto">
            Get comprehensive analysis of your business concept including competitor intelligence, 
            market research, financial projections, and success predictions—all in minutes.
          </p>

          {/* CTA Button */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16">
            <Link
              href="/validator"
              className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200"
            >
              <span>🚀 Launch VentureIQ</span>
            </Link>
            
            <a
              href="#features"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 text-lg font-semibold rounded-xl shadow-md hover:shadow-lg transition-all duration-200 border border-gray-200 dark:border-gray-700"
            >
              <span>Learn More</span>
            </a>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-20">
            <div className="p-6 bg-white dark:bg-gray-800 rounded-2xl shadow-md">
              <div className="text-3xl font-bold text-indigo-600 dark:text-indigo-400 mb-2">7+</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Competitors Analyzed</div>
            </div>
            <div className="p-6 bg-white dark:bg-gray-800 rounded-2xl shadow-md">
              <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-2">36</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Months Projected</div>
            </div>
            <div className="p-6 bg-white dark:bg-gray-800 rounded-2xl shadow-md">
              <div className="text-3xl font-bold text-pink-600 dark:text-pink-400 mb-2">100%</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Success Score</div>
            </div>
            <div className="p-6 bg-white dark:bg-gray-800 rounded-2xl shadow-md">
              <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">20+</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Page PDF Report</div>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div id="features" className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            Comprehensive Validation in Minutes
          </h2>
          <p className="text-center text-gray-600 dark:text-gray-400 mb-12 text-lg">
            Everything you need to validate your business idea before investing time and money
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="p-8 bg-white dark:bg-gray-800 rounded-2xl shadow-lg hover:shadow-xl transition-shadow border border-gray-100 dark:border-gray-700">
              <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/30 rounded-xl flex items-center justify-center mb-4">
                <span className="text-2xl">🎯</span>
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">Idea Parser</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Automatically extracts industry, target customer, problem, solution, and business model 
                from your description with accurate classification.
              </p>
            </div>

            {/* Feature 2 - PRIMARY */}
            <div className="p-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl shadow-lg hover:shadow-xl transition-shadow text-white">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mb-4">
                <span className="text-2xl">🔍</span>
              </div>
              <div className="inline-block px-3 py-1 bg-white/20 rounded-full text-xs font-semibold mb-3">
                PRIMARY FEATURE
              </div>
              <h3 className="text-xl font-bold mb-3">Competitor Intelligence</h3>
              <p className="text-white/90">
                Finds 5-10 competitors, scrapes pricing & features, creates comparison matrix, 
                and identifies market gaps with comprehensive fallback data.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="p-8 bg-white dark:bg-gray-800 rounded-2xl shadow-lg hover:shadow-xl transition-shadow border border-gray-100 dark:border-gray-700">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-xl flex items-center justify-center mb-4">
                <span className="text-2xl">📊</span>
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">Market Research</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Niche-specific market size analysis, industry trends, customer needs validation, 
                and entry barrier assessment.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="p-8 bg-white dark:bg-gray-800 rounded-2xl shadow-lg hover:shadow-xl transition-shadow border border-gray-100 dark:border-gray-700">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-xl flex items-center justify-center mb-4">
                <span className="text-2xl">💰</span>
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">Financial Modeling</h3>
              <p className="text-gray-600 dark:text-gray-400">
                3-year revenue projections with clear assumptions, monthly breakdown, 
                and interactive scenario planning with charts.
              </p>
            </div>

            {/* Feature 5 */}
            <div className="p-8 bg-white dark:bg-gray-800 rounded-2xl shadow-lg hover:shadow-xl transition-shadow border border-gray-100 dark:border-gray-700">
              <div className="w-12 h-12 bg-yellow-100 dark:bg-yellow-900/30 rounded-xl flex items-center justify-center mb-4">
                <span className="text-2xl">🎲</span>
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">Success Predictor</h3>
              <p className="text-gray-600 dark:text-gray-400">
                AI-powered success score (0-100%) based on market size, competition, uniqueness, 
                and timing with detailed reasoning.
              </p>
            </div>

            {/* Feature 6 */}
            <div className="p-8 bg-white dark:bg-gray-800 rounded-2xl shadow-lg hover:shadow-xl transition-shadow border border-gray-100 dark:border-gray-700">
              <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-xl flex items-center justify-center mb-4">
                <span className="text-2xl">📄</span>
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">PDF Reports</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Professional 15-20 page reports with executive summary, market analysis, 
                competitor profiles, and actionable recommendations.
              </p>
            </div>
          </div>
        </div>

        {/* How It Works */}
        <div className="max-w-4xl mx-auto mt-20">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            How It Works
          </h2>

          <div className="space-y-6">
            <div className="flex gap-4 items-start">
              <div className="flex-shrink-0 w-10 h-10 bg-indigo-600 text-white rounded-full flex items-center justify-center font-bold">
                1
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-gray-900 dark:text-white">Describe Your Idea</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Enter your business concept, target customers, problem solved, and business model in natural language.
                </p>
              </div>
            </div>

            <div className="flex gap-4 items-start">
              <div className="flex-shrink-0 w-10 h-10 bg-purple-600 text-white rounded-full flex items-center justify-center font-bold">
                2
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-gray-900 dark:text-white">AI Analysis</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Watch real-time progress as our AI analyzes competitors, researches the market, and models financials.
                </p>
              </div>
            </div>

            <div className="flex gap-4 items-start">
              <div className="flex-shrink-0 w-10 h-10 bg-pink-600 text-white rounded-full flex items-center justify-center font-bold">
                3
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-gray-900 dark:text-white">Get Insights</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Explore interactive dashboards with success scores, competitor comparisons, and financial projections.
                </p>
              </div>
            </div>

            <div className="flex gap-4 items-start">
              <div className="flex-shrink-0 w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">
                4
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-gray-900 dark:text-white">Download Report</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Generate and download a comprehensive PDF report to share with co-founders and investors.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Final CTA */}
        <div className="max-w-4xl mx-auto mt-20 p-12 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-3xl text-center text-white shadow-2xl">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Validate Your Idea?
          </h2>
          <p className="text-xl mb-8 text-white/90">
            Join entrepreneurs who validate before they build
          </p>
          <Link
            href="/validator"
            className="inline-flex items-center gap-2 px-10 py-5 bg-white text-indigo-600 text-lg font-bold rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200"
          >
            <span>🚀 Launch VentureIQ Now</span>
          </Link>
          <p className="mt-6 text-sm text-white/70">
            Free to use • No credit card required • Instant results
          </p>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-200 dark:border-gray-800 mt-20">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-gray-600 dark:text-gray-400">
              © 2024 VentureIQ. Built with AI.
            </div>
            <div className="flex gap-6">
              <a href="#" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
                About
              </a>
              <a href="#features" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
                Features
              </a>
              <Link href="/validator" className="text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
                Launch App
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}