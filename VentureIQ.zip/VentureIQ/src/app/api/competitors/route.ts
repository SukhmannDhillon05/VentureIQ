import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { competitors } from '@/db/schema';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Determine if input is single object or array
    const isArray = Array.isArray(body);
    const competitorsArray = isArray ? body : [body];
    
    // Validate each competitor
    const validatedCompetitors = [];
    for (let i = 0; i < competitorsArray.length; i++) {
      const competitor = competitorsArray[i];
      
      // Validate required fields
      if (!competitor.ideaId || typeof competitor.ideaId !== 'number') {
        return NextResponse.json({ 
          error: `Competitor at index ${i}: ideaId is required and must be a number`,
          code: "INVALID_IDEA_ID" 
        }, { status: 400 });
      }
      
      if (!competitor.name || typeof competitor.name !== 'string' || competitor.name.trim() === '') {
        return NextResponse.json({ 
          error: `Competitor at index ${i}: name is required and must be a non-empty string`,
          code: "INVALID_NAME" 
        }, { status: 400 });
      }
      
      // Build validated competitor object without id field
      const validatedCompetitor: any = {
        ideaId: competitor.ideaId,
        name: competitor.name.trim(),
        createdAt: new Date().toISOString()
      };
      
      // Add optional fields if provided
      if (competitor.website !== undefined && competitor.website !== null) {
        validatedCompetitor.website = typeof competitor.website === 'string' ? competitor.website.trim() : competitor.website;
      }
      
      if (competitor.pricing !== undefined && competitor.pricing !== null) {
        validatedCompetitor.pricing = typeof competitor.pricing === 'string' ? competitor.pricing.trim() : competitor.pricing;
      }
      
      if (competitor.features !== undefined && competitor.features !== null) {
        validatedCompetitor.features = typeof competitor.features === 'string' ? competitor.features.trim() : competitor.features;
      }
      
      if (competitor.positioning !== undefined && competitor.positioning !== null) {
        validatedCompetitor.positioning = typeof competitor.positioning === 'string' ? competitor.positioning.trim() : competitor.positioning;
      }
      
      if (competitor.marketGap !== undefined && competitor.marketGap !== null) {
        validatedCompetitor.marketGap = typeof competitor.marketGap === 'string' ? competitor.marketGap.trim() : competitor.marketGap;
      }
      
      validatedCompetitors.push(validatedCompetitor);
    }
    
    // Insert all competitors
    const newCompetitors = await db.insert(competitors)
      .values(validatedCompetitors)
      .returning();
    
    // Return single object if input was single object, array if input was array
    return NextResponse.json(isArray ? newCompetitors : newCompetitors[0], { status: 201 });
    
  } catch (error: any) {
    console.error('POST error:', error);
    return NextResponse.json({ 
      error: 'Internal server error: ' + error.message 
    }, { status: 500 });
  }
}