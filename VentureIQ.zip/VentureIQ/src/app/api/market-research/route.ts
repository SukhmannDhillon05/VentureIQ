import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { marketResearch } from '@/db/schema';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { ideaId, marketSize, industryTrends, customerNeeds, entryBarriers } = body;

    // Validate required fields
    if (!ideaId) {
      return NextResponse.json(
        { error: 'ideaId is required', code: 'MISSING_IDEA_ID' },
        { status: 400 }
      );
    }

    if (!marketSize || typeof marketSize !== 'string' || marketSize.trim() === '') {
      return NextResponse.json(
        { error: 'marketSize is required and must be a non-empty string', code: 'INVALID_MARKET_SIZE' },
        { status: 400 }
      );
    }

    if (!industryTrends || typeof industryTrends !== 'string' || industryTrends.trim() === '') {
      return NextResponse.json(
        { error: 'industryTrends is required and must be a non-empty string', code: 'INVALID_INDUSTRY_TRENDS' },
        { status: 400 }
      );
    }

    if (!customerNeeds || typeof customerNeeds !== 'string' || customerNeeds.trim() === '') {
      return NextResponse.json(
        { error: 'customerNeeds is required and must be a non-empty string', code: 'INVALID_CUSTOMER_NEEDS' },
        { status: 400 }
      );
    }

    if (!entryBarriers || typeof entryBarriers !== 'string' || entryBarriers.trim() === '') {
      return NextResponse.json(
        { error: 'entryBarriers is required and must be a non-empty string', code: 'INVALID_ENTRY_BARRIERS' },
        { status: 400 }
      );
    }

    // Validate ideaId is a valid integer
    const parsedIdeaId = parseInt(ideaId);
    if (isNaN(parsedIdeaId)) {
      return NextResponse.json(
        { error: 'ideaId must be a valid integer', code: 'INVALID_IDEA_ID' },
        { status: 400 }
      );
    }

    // Sanitize inputs
    const sanitizedData = {
      ideaId: parsedIdeaId,
      marketSize: marketSize.trim(),
      industryTrends: industryTrends.trim(),
      customerNeeds: customerNeeds.trim(),
      entryBarriers: entryBarriers.trim(),
      createdAt: new Date().toISOString(),
    };

    // Insert market research
    const newMarketResearch = await db.insert(marketResearch)
      .values(sanitizedData)
      .returning();

    return NextResponse.json(newMarketResearch[0], { status: 201 });
  } catch (error) {
    console.error('POST error:', error);
    return NextResponse.json(
      { error: 'Internal server error: ' + (error instanceof Error ? error.message : 'Unknown error') },
      { status: 500 }
    );
  }
}