import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { marketResearch } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    const ideaId = request.nextUrl.pathname.split('/').pop();

    if (!ideaId || isNaN(parseInt(ideaId))) {
      return NextResponse.json(
        { 
          error: 'Valid ideaId is required',
          code: 'INVALID_IDEA_ID'
        },
        { status: 400 }
      );
    }

    const result = await db.select()
      .from(marketResearch)
      .where(eq(marketResearch.ideaId, parseInt(ideaId)))
      .limit(1);

    if (result.length === 0) {
      return NextResponse.json(null, { status: 200 });
    }

    return NextResponse.json(result[0], { status: 200 });
  } catch (error) {
    console.error('GET error:', error);
    return NextResponse.json(
      { 
        error: 'Internal server error: ' + (error instanceof Error ? error.message : 'Unknown error')
      },
      { status: 500 }
    );
  }
}