import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { validationResults } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    // Extract ideaId from pathname
    const ideaId = request.nextUrl.pathname.split('/').pop();

    // Validate ideaId is valid integer
    if (!ideaId || isNaN(parseInt(ideaId))) {
      return NextResponse.json(
        { 
          error: 'Valid idea ID is required',
          code: 'INVALID_IDEA_ID' 
        },
        { status: 400 }
      );
    }

    const parsedIdeaId = parseInt(ideaId);

    // Query validation results where ideaId matches
    const results = await db
      .select()
      .from(validationResults)
      .where(eq(validationResults.ideaId, parsedIdeaId));

    // Return 200 with array of validation results (may be empty array if none exist)
    return NextResponse.json(results, { status: 200 });

  } catch (error) {
    console.error('GET validation results error:', error);
    return NextResponse.json(
      { 
        error: 'Internal server error: ' + (error instanceof Error ? error.message : 'Unknown error')
      },
      { status: 500 }
    );
  }
}