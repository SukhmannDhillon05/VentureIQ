import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { validationResults } from '@/db/schema';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      ideaId,
      successScore,
      marketScore,
      competitionScore,
      uniquenessScore,
      timingScore,
      reasoning,
      dataQuality
    } = body;

    // Validate all required fields are present
    if (!ideaId) {
      return NextResponse.json({
        error: 'ideaId is required',
        code: 'MISSING_IDEA_ID'
      }, { status: 400 });
    }

    if (successScore === undefined || successScore === null) {
      return NextResponse.json({
        error: 'successScore is required',
        code: 'MISSING_SUCCESS_SCORE'
      }, { status: 400 });
    }

    if (marketScore === undefined || marketScore === null) {
      return NextResponse.json({
        error: 'marketScore is required',
        code: 'MISSING_MARKET_SCORE'
      }, { status: 400 });
    }

    if (competitionScore === undefined || competitionScore === null) {
      return NextResponse.json({
        error: 'competitionScore is required',
        code: 'MISSING_COMPETITION_SCORE'
      }, { status: 400 });
    }

    if (uniquenessScore === undefined || uniquenessScore === null) {
      return NextResponse.json({
        error: 'uniquenessScore is required',
        code: 'MISSING_UNIQUENESS_SCORE'
      }, { status: 400 });
    }

    if (timingScore === undefined || timingScore === null) {
      return NextResponse.json({
        error: 'timingScore is required',
        code: 'MISSING_TIMING_SCORE'
      }, { status: 400 });
    }

    if (!reasoning || typeof reasoning !== 'string' || reasoning.trim() === '') {
      return NextResponse.json({
        error: 'reasoning is required and must be a non-empty string',
        code: 'INVALID_REASONING'
      }, { status: 400 });
    }

    if (!dataQuality || typeof dataQuality !== 'string' || dataQuality.trim() === '') {
      return NextResponse.json({
        error: 'dataQuality is required and must be a non-empty string',
        code: 'INVALID_DATA_QUALITY'
      }, { status: 400 });
    }

    // Validate ideaId is a valid integer
    const parsedIdeaId = parseInt(ideaId);
    if (isNaN(parsedIdeaId)) {
      return NextResponse.json({
        error: 'ideaId must be a valid integer',
        code: 'INVALID_IDEA_ID'
      }, { status: 400 });
    }

    // Validate all scores are integers
    const parsedSuccessScore = parseInt(successScore);
    const parsedMarketScore = parseInt(marketScore);
    const parsedCompetitionScore = parseInt(competitionScore);
    const parsedUniquenessScore = parseInt(uniquenessScore);
    const parsedTimingScore = parseInt(timingScore);

    if (isNaN(parsedSuccessScore)) {
      return NextResponse.json({
        error: 'successScore must be a valid integer',
        code: 'INVALID_SUCCESS_SCORE'
      }, { status: 400 });
    }

    if (isNaN(parsedMarketScore)) {
      return NextResponse.json({
        error: 'marketScore must be a valid integer',
        code: 'INVALID_MARKET_SCORE'
      }, { status: 400 });
    }

    if (isNaN(parsedCompetitionScore)) {
      return NextResponse.json({
        error: 'competitionScore must be a valid integer',
        code: 'INVALID_COMPETITION_SCORE'
      }, { status: 400 });
    }

    if (isNaN(parsedUniquenessScore)) {
      return NextResponse.json({
        error: 'uniquenessScore must be a valid integer',
        code: 'INVALID_UNIQUENESS_SCORE'
      }, { status: 400 });
    }

    if (isNaN(parsedTimingScore)) {
      return NextResponse.json({
        error: 'timingScore must be a valid integer',
        code: 'INVALID_TIMING_SCORE'
      }, { status: 400 });
    }

    // Validate all scores are between 0-100
    if (parsedSuccessScore < 0 || parsedSuccessScore > 100) {
      return NextResponse.json({
        error: 'successScore must be between 0 and 100',
        code: 'SUCCESS_SCORE_OUT_OF_RANGE'
      }, { status: 400 });
    }

    if (parsedMarketScore < 0 || parsedMarketScore > 100) {
      return NextResponse.json({
        error: 'marketScore must be between 0 and 100',
        code: 'MARKET_SCORE_OUT_OF_RANGE'
      }, { status: 400 });
    }

    if (parsedCompetitionScore < 0 || parsedCompetitionScore > 100) {
      return NextResponse.json({
        error: 'competitionScore must be between 0 and 100',
        code: 'COMPETITION_SCORE_OUT_OF_RANGE'
      }, { status: 400 });
    }

    if (parsedUniquenessScore < 0 || parsedUniquenessScore > 100) {
      return NextResponse.json({
        error: 'uniquenessScore must be between 0 and 100',
        code: 'UNIQUENESS_SCORE_OUT_OF_RANGE'
      }, { status: 400 });
    }

    if (parsedTimingScore < 0 || parsedTimingScore > 100) {
      return NextResponse.json({
        error: 'timingScore must be between 0 and 100',
        code: 'TIMING_SCORE_OUT_OF_RANGE'
      }, { status: 400 });
    }

    // Insert validation result
    const newValidationResult = await db.insert(validationResults)
      .values({
        ideaId: parsedIdeaId,
        successScore: parsedSuccessScore,
        marketScore: parsedMarketScore,
        competitionScore: parsedCompetitionScore,
        uniquenessScore: parsedUniquenessScore,
        timingScore: parsedTimingScore,
        reasoning: reasoning.trim(),
        dataQuality: dataQuality.trim(),
        createdAt: new Date().toISOString()
      })
      .returning();

    return NextResponse.json(newValidationResult[0], { status: 201 });

  } catch (error) {
    console.error('POST error:', error);
    return NextResponse.json({
      error: 'Internal server error: ' + (error instanceof Error ? error.message : 'Unknown error')
    }, { status: 500 });
  }
}