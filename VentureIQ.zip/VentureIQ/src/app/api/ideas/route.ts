import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { ideas } from '@/db/schema';
import { eq, like, or, desc } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const limit = Math.min(parseInt(searchParams.get('limit') ?? '10'), 100);
    const offset = parseInt(searchParams.get('offset') ?? '0');
    const search = searchParams.get('search');

    let query = db.select().from(ideas).orderBy(desc(ideas.createdAt));

    if (search) {
      const trimmedSearch = search.trim();
      query = query.where(
        or(
          like(ideas.title, `%${trimmedSearch}%`),
          like(ideas.description, `%${trimmedSearch}%`),
          like(ideas.industry, `%${trimmedSearch}%`)
        )
      );
    }

    const results = await query.limit(limit).offset(offset);

    return NextResponse.json(results, { status: 200 });
  } catch (error) {
    console.error('GET error:', error);
    return NextResponse.json(
      { error: 'Internal server error: ' + (error as Error).message },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const {
      userIdentifier,
      title,
      description,
      industry,
      targetCustomer,
      problem,
      solution,
      businessModel,
    } = body;

    // Validate required fields
    if (!userIdentifier || typeof userIdentifier !== 'string' || userIdentifier.trim() === '') {
      return NextResponse.json(
        {
          error: 'userIdentifier is required and must be a non-empty string',
          code: 'MISSING_USER_IDENTIFIER',
        },
        { status: 400 }
      );
    }

    if (!title || typeof title !== 'string' || title.trim() === '') {
      return NextResponse.json(
        {
          error: 'title is required and must be a non-empty string',
          code: 'MISSING_TITLE',
        },
        { status: 400 }
      );
    }

    if (!description || typeof description !== 'string' || description.trim() === '') {
      return NextResponse.json(
        {
          error: 'description is required and must be a non-empty string',
          code: 'MISSING_DESCRIPTION',
        },
        { status: 400 }
      );
    }

    if (!industry || typeof industry !== 'string' || industry.trim() === '') {
      return NextResponse.json(
        {
          error: 'industry is required and must be a non-empty string',
          code: 'MISSING_INDUSTRY',
        },
        { status: 400 }
      );
    }

    if (!targetCustomer || typeof targetCustomer !== 'string' || targetCustomer.trim() === '') {
      return NextResponse.json(
        {
          error: 'targetCustomer is required and must be a non-empty string',
          code: 'MISSING_TARGET_CUSTOMER',
        },
        { status: 400 }
      );
    }

    if (!problem || typeof problem !== 'string' || problem.trim() === '') {
      return NextResponse.json(
        {
          error: 'problem is required and must be a non-empty string',
          code: 'MISSING_PROBLEM',
        },
        { status: 400 }
      );
    }

    if (!solution || typeof solution !== 'string' || solution.trim() === '') {
      return NextResponse.json(
        {
          error: 'solution is required and must be a non-empty string',
          code: 'MISSING_SOLUTION',
        },
        { status: 400 }
      );
    }

    if (!businessModel || typeof businessModel !== 'string' || businessModel.trim() === '') {
      return NextResponse.json(
        {
          error: 'businessModel is required and must be a non-empty string',
          code: 'MISSING_BUSINESS_MODEL',
        },
        { status: 400 }
      );
    }

    // Create new idea with sanitized inputs
    const newIdea = await db
      .insert(ideas)
      .values({
        userIdentifier: userIdentifier.trim(),
        title: title.trim(),
        description: description.trim(),
        industry: industry.trim(),
        targetCustomer: targetCustomer.trim(),
        problem: problem.trim(),
        solution: solution.trim(),
        businessModel: businessModel.trim(),
        createdAt: new Date().toISOString(),
      })
      .returning();

    return NextResponse.json(newIdea[0], { status: 201 });
  } catch (error) {
    console.error('POST error:', error);
    return NextResponse.json(
      { error: 'Internal server error: ' + (error as Error).message },
      { status: 500 }
    );
  }
}