import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { ideas, validationResults, competitors, marketResearch, financialProjections } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    const id = request.nextUrl.pathname.split('/').pop();

    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json({ 
        error: "Valid ID is required",
        code: "INVALID_ID" 
      }, { status: 400 });
    }

    const ideaId = parseInt(id);

    // Load idea
    const ideaResult = await db.select()
      .from(ideas)
      .where(eq(ideas.id, ideaId))
      .limit(1);

    if (ideaResult.length === 0) {
      return NextResponse.json({ 
        error: 'Idea not found',
        code: 'IDEA_NOT_FOUND' 
      }, { status: 404 });
    }

    // Load all related data
    const validationResultsData = await db.select()
      .from(validationResults)
      .where(eq(validationResults.ideaId, ideaId));

    const competitorsData = await db.select()
      .from(competitors)
      .where(eq(competitors.ideaId, ideaId));

    const marketResearchData = await db.select()
      .from(marketResearch)
      .where(eq(marketResearch.ideaId, ideaId));

    const financialProjectionsData = await db.select()
      .from(financialProjections)
      .where(eq(financialProjections.ideaId, ideaId));

    return NextResponse.json({
      idea: ideaResult[0],
      validationResults: validationResultsData,
      competitors: competitorsData,
      marketResearch: marketResearchData.length > 0 ? marketResearchData[0] : null,
      financialProjections: financialProjectionsData.length > 0 ? financialProjectionsData[0] : null
    }, { status: 200 });

  } catch (error) {
    console.error('GET error:', error);
    return NextResponse.json({ 
      error: 'Internal server error: ' + (error instanceof Error ? error.message : 'Unknown error')
    }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const id = request.nextUrl.pathname.split('/').pop();

    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json({ 
        error: "Valid ID is required",
        code: "INVALID_ID" 
      }, { status: 400 });
    }

    const ideaId = parseInt(id);

    // Check if idea exists
    const existingIdea = await db.select()
      .from(ideas)
      .where(eq(ideas.id, ideaId))
      .limit(1);

    if (existingIdea.length === 0) {
      return NextResponse.json({ 
        error: 'Idea not found',
        code: 'IDEA_NOT_FOUND' 
      }, { status: 404 });
    }

    const body = await request.json();

    // Extract allowed fields for update
    const allowedFields = [
      'title',
      'description',
      'industry',
      'targetCustomer',
      'problem',
      'solution',
      'businessModel'
    ];

    const updates: any = {};
    
    for (const field of allowedFields) {
      if (field in body) {
        updates[field] = body[field];
      }
    }

    // If no valid fields to update
    if (Object.keys(updates).length === 0) {
      return NextResponse.json({ 
        error: 'No valid fields provided for update',
        code: 'NO_VALID_FIELDS' 
      }, { status: 400 });
    }

    // Update the idea
    const updated = await db.update(ideas)
      .set(updates)
      .where(eq(ideas.id, ideaId))
      .returning();

    return NextResponse.json(updated[0], { status: 200 });

  } catch (error) {
    console.error('PUT error:', error);
    return NextResponse.json({ 
      error: 'Internal server error: ' + (error instanceof Error ? error.message : 'Unknown error')
    }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.pathname.split('/').pop();

    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json({ 
        error: "Valid ID is required",
        code: "INVALID_ID" 
      }, { status: 400 });
    }

    const ideaId = parseInt(id);

    // Check if idea exists
    const existingIdea = await db.select()
      .from(ideas)
      .where(eq(ideas.id, ideaId))
      .limit(1);

    if (existingIdea.length === 0) {
      return NextResponse.json({ 
        error: 'Idea not found',
        code: 'IDEA_NOT_FOUND' 
      }, { status: 404 });
    }

    // Delete related data first (foreign key constraints)
    await db.delete(validationResults)
      .where(eq(validationResults.ideaId, ideaId));

    await db.delete(competitors)
      .where(eq(competitors.ideaId, ideaId));

    await db.delete(marketResearch)
      .where(eq(marketResearch.ideaId, ideaId));

    await db.delete(financialProjections)
      .where(eq(financialProjections.ideaId, ideaId));

    // Delete the idea
    await db.delete(ideas)
      .where(eq(ideas.id, ideaId))
      .returning();

    return NextResponse.json({
      message: "Idea deleted successfully",
      id: ideaId
    }, { status: 200 });

  } catch (error) {
    console.error('DELETE error:', error);
    return NextResponse.json({ 
      error: 'Internal server error: ' + (error instanceof Error ? error.message : 'Unknown error')
    }, { status: 500 });
  }
}