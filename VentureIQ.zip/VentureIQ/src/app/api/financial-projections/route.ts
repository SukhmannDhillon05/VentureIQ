import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { financialProjections } from '@/db/schema';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { ideaId, assumptions, year1Revenue, year2Revenue, year3Revenue, monthlyBreakdown } = body;

    // Validate required fields
    if (!ideaId) {
      return NextResponse.json({ 
        error: "ideaId is required",
        code: "MISSING_IDEA_ID" 
      }, { status: 400 });
    }

    if (!assumptions) {
      return NextResponse.json({ 
        error: "assumptions is required",
        code: "MISSING_ASSUMPTIONS" 
      }, { status: 400 });
    }

    if (year1Revenue === undefined || year1Revenue === null) {
      return NextResponse.json({ 
        error: "year1Revenue is required",
        code: "MISSING_YEAR1_REVENUE" 
      }, { status: 400 });
    }

    if (year2Revenue === undefined || year2Revenue === null) {
      return NextResponse.json({ 
        error: "year2Revenue is required",
        code: "MISSING_YEAR2_REVENUE" 
      }, { status: 400 });
    }

    if (year3Revenue === undefined || year3Revenue === null) {
      return NextResponse.json({ 
        error: "year3Revenue is required",
        code: "MISSING_YEAR3_REVENUE" 
      }, { status: 400 });
    }

    if (!monthlyBreakdown) {
      return NextResponse.json({ 
        error: "monthlyBreakdown is required",
        code: "MISSING_MONTHLY_BREAKDOWN" 
      }, { status: 400 });
    }

    // Validate ideaId is valid integer
    const parsedIdeaId = parseInt(ideaId);
    if (isNaN(parsedIdeaId)) {
      return NextResponse.json({ 
        error: "ideaId must be a valid integer",
        code: "INVALID_IDEA_ID" 
      }, { status: 400 });
    }

    // Validate revenue fields are positive integers
    const parsedYear1Revenue = parseInt(year1Revenue);
    const parsedYear2Revenue = parseInt(year2Revenue);
    const parsedYear3Revenue = parseInt(year3Revenue);

    if (isNaN(parsedYear1Revenue) || parsedYear1Revenue < 0) {
      return NextResponse.json({ 
        error: "year1Revenue must be a positive integer",
        code: "INVALID_YEAR1_REVENUE" 
      }, { status: 400 });
    }

    if (isNaN(parsedYear2Revenue) || parsedYear2Revenue < 0) {
      return NextResponse.json({ 
        error: "year2Revenue must be a positive integer",
        code: "INVALID_YEAR2_REVENUE" 
      }, { status: 400 });
    }

    if (isNaN(parsedYear3Revenue) || parsedYear3Revenue < 0) {
      return NextResponse.json({ 
        error: "year3Revenue must be a positive integer",
        code: "INVALID_YEAR3_REVENUE" 
      }, { status: 400 });
    }

    // Convert assumptions and monthlyBreakdown to JSON strings if they are objects
    const processedAssumptions = typeof assumptions === 'object' 
      ? JSON.stringify(assumptions) 
      : assumptions;

    const processedMonthlyBreakdown = typeof monthlyBreakdown === 'object' 
      ? JSON.stringify(monthlyBreakdown) 
      : monthlyBreakdown;

    // Insert financial projection without id field
    const newProjection = await db.insert(financialProjections)
      .values({
        ideaId: parsedIdeaId,
        assumptions: processedAssumptions,
        year1Revenue: parsedYear1Revenue,
        year2Revenue: parsedYear2Revenue,
        year3Revenue: parsedYear3Revenue,
        monthlyBreakdown: processedMonthlyBreakdown,
        createdAt: new Date().toISOString()
      })
      .returning();

    return NextResponse.json(newProjection[0], { status: 201 });

  } catch (error) {
    console.error('POST error:', error);
    return NextResponse.json({ 
      error: 'Internal server error: ' + (error as Error).message 
    }, { status: 500 });
  }
}