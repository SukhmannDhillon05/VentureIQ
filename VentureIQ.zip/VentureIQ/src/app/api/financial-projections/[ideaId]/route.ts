import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { financialProjections } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    // Extract ideaId from pathname
    const ideaId = request.nextUrl.pathname.split('/').pop();

    // Validate ideaId is valid integer
    if (!ideaId || isNaN(parseInt(ideaId))) {
      return NextResponse.json(
        { 
          error: 'Valid idea ID is required',
          code: 'INVALID_IDEA_ID' 
        },
        { status: 400 }
      );
    }

    const parsedIdeaId = parseInt(ideaId);

    // Query financial projections where ideaId matches
    const projection = await db
      .select()
      .from(financialProjections)
      .where(eq(financialProjections.ideaId, parsedIdeaId))
      .limit(1);

    // Return 200 with single financial projection object or null if not found
    if (projection.length === 0) {
      return NextResponse.json(null, { status: 200 });
    }

    return NextResponse.json(projection[0], { status: 200 });
  } catch (error) {
    console.error('GET financial projections error:', error);
    return NextResponse.json(
      { 
        error: 'Internal server error: ' + (error as Error).message 
      },
      { status: 500 }
    );
  }
}