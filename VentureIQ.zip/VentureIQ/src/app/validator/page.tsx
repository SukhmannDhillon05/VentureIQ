"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { IdeaFormStep1 } from "@/components/validator/idea-form-step1";
import { IdeaFormStep2 } from "@/components/validator/idea-form-step2";
import { ValidationProgress } from "@/components/validator/validation-progress";
import { ResultsDashboard } from "@/components/validator/results-dashboard";
import { 
  classifyIndustry, 
  generateMockCompetitors, 
  generateMarketResearch, 
  generateFinancialProjections,
  calculateSuccessScore 
} from "@/lib/validators/idea-validator";
import jsPDF from "jspdf";

const formSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters"),
  description: z.string().min(20, "Description must be at least 20 characters"),
  targetCustomer: z.string().min(20, "Target customer must be at least 20 characters"),
  problem: z.string().min(20, "Problem statement must be at least 20 characters"),
  solution: z.string().min(20, "Solution must be at least 20 characters"),
  businessModel: z.string().min(10, "Business model must be at least 10 characters"),
});

type FormData = z.infer<typeof formSchema>;

export default function ValidatorPage() {
  const [step, setStep] = useState(1);
  const [isValidating, setIsValidating] = useState(false);
  const [validationStep, setValidationStep] = useState(0);
  const [validationData, setValidationData] = useState<any>(null);
  const [userIdentifier] = useState(() => `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      targetCustomer: "",
      problem: "",
      solution: "",
      businessModel: "",
    },
  });

  const onSubmit = async (data: FormData) => {
    setIsValidating(true);
    setValidationStep(0);

    try {
      // Step 1: Parse idea and classify industry
      await new Promise(resolve => setTimeout(resolve, 1500));
      setValidationStep(1);
      const industry = classifyIndustry(data.description, data.solution);

      // Step 2: Generate competitors
      await new Promise(resolve => setTimeout(resolve, 1500));
      setValidationStep(2);
      const competitors = generateMockCompetitors(
        industry, 
        data.solution,
        data.description,
        data.targetCustomer,
        data.problem
      );

      // Step 3: Generate market research
      await new Promise(resolve => setTimeout(resolve, 1500));
      setValidationStep(3);
      const marketResearch = generateMarketResearch(industry, data.targetCustomer, data.problem);

      // Step 4: Generate financial projections
      await new Promise(resolve => setTimeout(resolve, 1500));
      setValidationStep(4);
      const financialProjections = generateFinancialProjections(data.businessModel, industry);

      // Step 5: Calculate success score
      await new Promise(resolve => setTimeout(resolve, 1500));
      setValidationStep(5);
      const successScore = calculateSuccessScore(
        industry,
        data.problem,
        data.solution,
        data.targetCustomer,
        competitors
      );

      // Save to database
      const ideaResponse = await fetch("/api/ideas", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userIdentifier,
          title: data.title,
          description: data.description,
          industry,
          targetCustomer: data.targetCustomer,
          problem: data.problem,
          solution: data.solution,
          businessModel: data.businessModel,
        }),
      });

      if (!ideaResponse.ok) {
        throw new Error("Failed to save idea");
      }

      const ideaData = await ideaResponse.json();
      const ideaId = ideaData.id;

      // Save validation results
      await fetch("/api/validation-results", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ideaId,
          successScore: successScore.successScore,
          marketScore: successScore.marketScore,
          competitionScore: successScore.competitionScore,
          uniquenessScore: successScore.uniquenessScore,
          timingScore: successScore.timingScore,
          reasoning: successScore.reasoning,
          dataQuality: successScore.dataQuality,
        }),
      });

      // Save competitors
      await fetch("/api/competitors", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(competitors.map(c => ({ ...c, ideaId }))),
      });

      // Save market research
      await fetch("/api/market-research", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ideaId,
          marketSize: marketResearch.marketSize,
          industryTrends: marketResearch.industryTrends,
          customerNeeds: marketResearch.customerNeeds,
          entryBarriers: marketResearch.entryBarriers,
        }),
      });

      // Save financial projections
      await fetch("/api/financial-projections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ideaId,
          assumptions: financialProjections.assumptions,
          year1Revenue: financialProjections.year1Revenue,
          year2Revenue: financialProjections.year2Revenue,
          year3Revenue: financialProjections.year3Revenue,
          monthlyBreakdown: financialProjections.monthlyBreakdown,
        }),
      });

      // Fetch complete data
      const completeDataResponse = await fetch(`/api/ideas/${ideaId}`);
      const completeData = await completeDataResponse.json();

      setValidationData(completeData);
    } catch (error) {
      console.error("Validation error:", error);
      alert("An error occurred during validation. Please try again.");
    } finally {
      setIsValidating(false);
    }
  };

  const handleDownloadPDF = () => {
    if (!validationData) return;

    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const margin = 20;
      let yPos = 20;

      // Helper function to add new page if needed
      const checkAddPage = (requiredSpace: number = 30) => {
        if (yPos > pageHeight - requiredSpace) {
          doc.addPage();
          yPos = 20;
          return true;
        }
        return false;
      };

      // Helper function to add wrapped text
      const addWrappedText = (text: string, fontSize: number = 11, maxWidth?: number) => {
        doc.setFontSize(fontSize);
        const lines = doc.splitTextToSize(text, maxWidth || pageWidth - margin * 2);
        doc.text(lines, margin, yPos);
        yPos += lines.length * (fontSize * 0.4) + 5;
      };

      // ========== PAGE 1: COVER PAGE ==========
      doc.setFontSize(32);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(79, 70, 229); // Indigo
      doc.text("VentureIQ", pageWidth / 2, 60, { align: "center" });
      
      doc.setFontSize(24);
      doc.setTextColor(0, 0, 0);
      doc.text("Business Validation Report", pageWidth / 2, 80, { align: "center" });
      
      doc.setFontSize(18);
      doc.setFont("helvetica", "normal");
      const titleLines = doc.splitTextToSize(validationData.idea.title, pageWidth - 60);
      doc.text(titleLines, pageWidth / 2, 100, { align: "center" });
      
      doc.setFontSize(12);
      doc.setTextColor(100, 100, 100);
      doc.text(`Industry: ${validationData.idea.industry}`, pageWidth / 2, 130, { align: "center" });
      doc.text(`Generated: ${new Date().toLocaleDateString()}`, pageWidth / 2, 140, { align: "center" });
      
      // Success Score Badge
      yPos = 160;
      doc.setFontSize(14);
      doc.setTextColor(0, 0, 0);
      doc.text("Overall Success Score", pageWidth / 2, yPos, { align: "center" });
      
      yPos += 15;
      doc.setFontSize(48);
      const score = validationData.validationResults[0].successScore;
      doc.setTextColor(
        score >= 75 ? 34 : score >= 60 ? 245 : 220,
        score >= 75 ? 197 : score >= 60 ? 158 : 38,
        score >= 75 ? 94 : score >= 60 ? 11 : 38
      );
      doc.text(`${score}/100`, pageWidth / 2, yPos, { align: "center" });
      
      yPos += 20;
      doc.setFontSize(12);
      doc.setTextColor(0, 0, 0);
      doc.text(score >= 75 ? "Strong Potential" : score >= 60 ? "Moderate Potential" : "Needs Refinement", 
        pageWidth / 2, yPos, { align: "center" });

      // ========== PAGE 2: EXECUTIVE SUMMARY ==========
      doc.addPage();
      yPos = 20;
      
      doc.setFontSize(20);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(0, 0, 0);
      doc.text("Executive Summary", margin, yPos);
      yPos += 15;
      
      doc.setFontSize(14);
      doc.text("Business Concept", margin, yPos);
      yPos += 8;
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      addWrappedText(validationData.idea.description);
      yPos += 5;
      
      checkAddPage();
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("Target Customer", margin, yPos);
      yPos += 8;
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      addWrappedText(validationData.idea.targetCustomer);
      yPos += 5;
      
      checkAddPage();
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("Problem Statement", margin, yPos);
      yPos += 8;
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      addWrappedText(validationData.idea.problem);
      yPos += 5;
      
      checkAddPage();
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("Proposed Solution", margin, yPos);
      yPos += 8;
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      addWrappedText(validationData.idea.solution);
      yPos += 5;
      
      checkAddPage();
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("Business Model", margin, yPos);
      yPos += 8;
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      addWrappedText(validationData.idea.businessModel);

      // ========== PAGE 3: VALIDATION SCORES ==========
      doc.addPage();
      yPos = 20;
      
      doc.setFontSize(20);
      doc.setFont("helvetica", "bold");
      doc.text("Validation Analysis", margin, yPos);
      yPos += 15;
      
      const vr = validationData.validationResults[0];
      const scores = [
        { name: "Market Score", value: vr.marketScore, desc: "Market size, growth potential, and customer clarity" },
        { name: "Competition Score", value: vr.competitionScore, desc: "Competitive landscape and differentiation opportunities" },
        { name: "Uniqueness Score", value: vr.uniquenessScore, desc: "Innovation and unique value proposition" },
        { name: "Timing Score", value: vr.timingScore, desc: "Market readiness and industry trends alignment" }
      ];
      
      scores.forEach((item) => {
        checkAddPage(35);
        doc.setFontSize(14);
        doc.setFont("helvetica", "bold");
        doc.text(item.name, margin, yPos);
        
        doc.setFontSize(24);
        doc.setTextColor(
          item.value >= 75 ? 34 : item.value >= 60 ? 245 : 220,
          item.value >= 75 ? 197 : item.value >= 60 ? 158 : 38,
          item.value >= 75 ? 94 : item.value >= 60 ? 11 : 38
        );
        doc.text(`${item.value}/100`, pageWidth - margin - 30, yPos + 5);
        
        doc.setTextColor(0, 0, 0);
        yPos += 12;
        doc.setFontSize(10);
        doc.setFont("helvetica", "italic");
        addWrappedText(item.desc, 10);
        yPos += 3;
      });
      
      checkAddPage(40);
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("AI Analysis & Reasoning", margin, yPos);
      yPos += 10;
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      addWrappedText(vr.reasoning);

      // ========== PAGE 4-5: MARKET RESEARCH ==========
      doc.addPage();
      yPos = 20;
      
      doc.setFontSize(20);
      doc.setFont("helvetica", "bold");
      doc.text("Market Research Analysis", margin, yPos);
      yPos += 15;
      
      const mr = validationData.marketResearch;
      
      doc.setFontSize(14);
      doc.text("Market Size & Opportunity", margin, yPos);
      yPos += 10;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      addWrappedText(mr.marketSize);
      yPos += 5;
      
      checkAddPage();
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("Industry Trends", margin, yPos);
      yPos += 10;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      addWrappedText(mr.industryTrends);
      yPos += 5;
      
      checkAddPage();
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("Customer Needs & Behavior", margin, yPos);
      yPos += 10;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      addWrappedText(mr.customerNeeds);
      yPos += 5;
      
      checkAddPage();
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("Market Entry Barriers", margin, yPos);
      yPos += 10;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      addWrappedText(mr.entryBarriers);

      // ========== PAGE 6-10: COMPETITOR ANALYSIS ==========
      doc.addPage();
      yPos = 20;
      
      doc.setFontSize(20);
      doc.setFont("helvetica", "bold");
      doc.text("Competitive Intelligence", margin, yPos);
      yPos += 15;
      
      doc.setFontSize(12);
      doc.setFont("helvetica", "normal");
      doc.text(`Identified ${validationData.competitors.length} key competitors in the ${validationData.idea.industry} space.`, margin, yPos);
      yPos += 10;
      doc.text("Detailed analysis of each competitor's positioning, pricing, and market gaps:", margin, yPos);
      yPos += 15;
      
      validationData.competitors.forEach((competitor: any, idx: number) => {
        checkAddPage(70);
        
        // Competitor header with number
        doc.setFillColor(79, 70, 229);
        doc.rect(margin, yPos - 5, pageWidth - margin * 2, 12, "F");
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(14);
        doc.setFont("helvetica", "bold");
        doc.text(`${idx + 1}. ${competitor.name}`, margin + 5, yPos + 3);
        
        yPos += 15;
        doc.setTextColor(0, 0, 0);
        
        // Website
        doc.setFontSize(10);
        doc.setFont("helvetica", "normal");
        doc.setTextColor(79, 70, 229);
        doc.text(competitor.website, margin + 5, yPos);
        yPos += 8;
        doc.setTextColor(0, 0, 0);
        
        // Pricing
        doc.setFontSize(11);
        doc.setFont("helvetica", "bold");
        doc.text("Pricing:", margin + 5, yPos);
        doc.setFont("helvetica", "normal");
        doc.text(competitor.pricing, margin + 25, yPos);
        yPos += 8;
        
        // Features
        doc.setFont("helvetica", "bold");
        doc.text("Features:", margin + 5, yPos);
        yPos += 6;
        doc.setFont("helvetica", "normal");
        addWrappedText(competitor.features, 10, pageWidth - margin * 2 - 10);
        
        // Positioning
        checkAddPage(25);
        doc.setFont("helvetica", "bold");
        doc.text("Positioning:", margin + 5, yPos);
        yPos += 6;
        doc.setFont("helvetica", "normal");
        addWrappedText(competitor.positioning, 10, pageWidth - margin * 2 - 10);
        
        // Market Gap (highlighted)
        checkAddPage(25);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(220, 38, 38); // Red for gaps
        doc.text("Market Gap & Opportunity:", margin + 5, yPos);
        yPos += 6;
        doc.setFont("helvetica", "normal");
        doc.setTextColor(0, 0, 0);
        addWrappedText(competitor.marketGap, 10, pageWidth - margin * 2 - 10);
        
        yPos += 5;
      });

      // ========== COMPETITOR COMPARISON MATRIX ==========
      checkAddPage(80);
      doc.setFontSize(16);
      doc.setFont("helvetica", "bold");
      doc.text("Competitive Positioning Matrix", margin, yPos);
      yPos += 12;
      
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.text("Summary comparison of key competitors:", margin, yPos);
      yPos += 10;
      
      // Table header
      doc.setFillColor(240, 240, 240);
      doc.rect(margin, yPos, pageWidth - margin * 2, 8, "F");
      doc.setFont("helvetica", "bold");
      doc.text("Competitor", margin + 2, yPos + 5);
      doc.text("Pricing", margin + 50, yPos + 5);
      doc.text("Key Gap", margin + 90, yPos + 5);
      yPos += 10;
      
      // Table rows
      doc.setFont("helvetica", "normal");
      validationData.competitors.slice(0, 8).forEach((comp: any) => {
        checkAddPage(12);
        doc.text(comp.name.substring(0, 20), margin + 2, yPos);
        doc.text(comp.pricing.substring(0, 25), margin + 50, yPos);
        const gapText = comp.marketGap.substring(0, 35) + (comp.marketGap.length > 35 ? "..." : "");
        doc.text(gapText, margin + 90, yPos);
        yPos += 8;
      });

      // ========== PAGE 11-14: FINANCIAL PROJECTIONS ==========
      doc.addPage();
      yPos = 20;
      
      doc.setFontSize(20);
      doc.setFont("helvetica", "bold");
      doc.text("Financial Projections", margin, yPos);
      yPos += 15;
      
      const fp = validationData.financialProjections;
      
      // Revenue Projections
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("3-Year Revenue Projection", margin, yPos);
      yPos += 15;
      
      // Year boxes
      const years = [
        { label: "Year 1", value: fp.year1Revenue },
        { label: "Year 2", value: fp.year2Revenue },
        { label: "Year 3", value: fp.year3Revenue }
      ];
      
      years.forEach((year, idx) => {
        const xPos = margin + idx * 55;
        doc.setFillColor(249, 250, 251);
        doc.rect(xPos, yPos, 50, 30, "F");
        doc.setDrawColor(200, 200, 200);
        doc.rect(xPos, yPos, 50, 30);
        
        doc.setFontSize(10);
        doc.setFont("helvetica", "normal");
        doc.text(year.label, xPos + 25, yPos + 10, { align: "center" });
        
        doc.setFontSize(14);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(34, 197, 94); // Green
        doc.text(`$${(year.value / 1000000).toFixed(2)}M`, xPos + 25, yPos + 22, { align: "center" });
        doc.setTextColor(0, 0, 0);
      });
      
      yPos += 40;
      
      // Growth metrics
      const growth12 = ((fp.year2Revenue - fp.year1Revenue) / fp.year1Revenue * 100).toFixed(0);
      const growth23 = ((fp.year3Revenue - fp.year2Revenue) / fp.year2Revenue * 100).toFixed(0);
      
      doc.setFontSize(11);
      doc.setFont("helvetica", "normal");
      doc.text(`Year 1→2 Growth: ${growth12}%`, margin, yPos);
      doc.text(`Year 2→3 Growth: ${growth23}%`, margin + 70, yPos);
      yPos += 15;
      
      // Parse monthlyBreakdown if it's a string
      const monthlyBreakdown = typeof fp.monthlyBreakdown === 'string'
        ? JSON.parse(fp.monthlyBreakdown)
        : fp.monthlyBreakdown;
      
      // Monthly breakdown for Year 1
      checkAddPage(80);
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("Year 1 Monthly Revenue Breakdown", margin, yPos);
      yPos += 12;
      
      doc.setFontSize(9);
      doc.setFont("helvetica", "normal");
      
      // Monthly table
      for (let i = 1; i <= 12; i++) {
        if (i % 6 === 1 && i > 1) {
          yPos += 8;
          checkAddPage();
        }
        const monthRev = monthlyBreakdown[`month${i}`];
        const monthName = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][i - 1];
        doc.text(`${monthName}: $${(monthRev / 1000).toFixed(1)}K`, margin + ((i - 1) % 6) * 30, yPos);
        if (i % 6 === 0) yPos += 6;
      }
      
      yPos += 15;
      
      // Financial summary
      checkAddPage();
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("Financial Health Indicators", margin, yPos);
      yPos += 10;
      
      doc.setFontSize(11);
      doc.setFont("helvetica", "normal");
      
      // Parse assumptions for metrics calculation
      const assumptions = typeof fp.assumptions === 'string' 
        ? JSON.parse(fp.assumptions) 
        : fp.assumptions;
      
      const ltv = parseInt(assumptions.ltv.match(/\$(\d+)/)?.[1] || "0");
      const cac = parseInt(assumptions.cac.match(/\$(\d+)/)?.[1] || "0");
      const ltvCacRatio = (ltv / cac).toFixed(1);
      
      doc.text(`• LTV:CAC Ratio: ${ltvCacRatio}:1 ${ltvCacRatio > "3" ? "(Excellent)" : "(Good)"}`, margin + 5, yPos);
      yPos += 7;
      doc.text(`• Projected ARR (Year 3): $${(fp.year3Revenue / 1000000).toFixed(2)}M`, margin + 5, yPos);
      yPos += 7;
      doc.text(`• Average Monthly Growth (Year 1): ${(growth12 / 12).toFixed(1)}%`, margin + 5, yPos);

      // ========== PAGE 15-16: RECOMMENDATIONS ==========
      doc.addPage();
      yPos = 20;
      
      doc.setFontSize(20);
      doc.setFont("helvetica", "bold");
      doc.text("Strategic Recommendations", margin, yPos);
      yPos += 15;
      
      doc.setFontSize(14);
      doc.text("Go-to-Market Strategy", margin, yPos);
      yPos += 10;
      
      doc.setFontSize(11);
      doc.setFont("helvetica", "normal");
      const gtmStrategy = `Based on the competitive analysis, we recommend a multi-channel approach: (1) Content marketing to establish thought leadership in ${validationData.idea.industry}, (2) Strategic partnerships with complementary services to leverage existing customer bases, (3) Targeted paid advertising focusing on high-intent keywords, (4) Product-led growth strategy with freemium tier to lower adoption barriers. Focus initial efforts on ${validationData.idea.targetCustomer.split('.')[0]} as the primary customer segment.`;
      addWrappedText(gtmStrategy);
      yPos += 5;
      
      checkAddPage();
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("Product Development Priorities", margin, yPos);
      yPos += 10;
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      const productPriorities = `Key features to prioritize in MVP: (1) Core solution addressing ${validationData.idea.problem.substring(0, 100)}..., (2) Seamless onboarding experience to minimize time-to-value, (3) Integration capabilities with popular tools in the ${validationData.idea.industry} ecosystem, (4) Mobile responsiveness for on-the-go access. Post-MVP roadmap should focus on automation features and analytics based on early user feedback.`;
      addWrappedText(productPriorities);
      yPos += 5;
      
      checkAddPage();
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("Risk Mitigation", margin, yPos);
      yPos += 10;
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      const risks = `Primary risks and mitigation strategies: (1) Market Competition - Differentiate through ${vr.uniquenessScore >= 70 ? 'superior UX and focused niche positioning' : 'enhanced features and better customer service'}, (2) Customer Acquisition Costs - Implement referral program and optimize conversion funnel, (3) Product-Market Fit - Conduct regular user interviews and iterate quickly based on feedback, (4) Technical Challenges - Build with scalable architecture from day one and maintain technical debt discipline.`;
      addWrappedText(risks);
      yPos += 5;
      
      checkAddPage();
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("Funding & Resource Requirements", margin, yPos);
      yPos += 10;
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      const funding = `Recommended initial funding: $${((fp.year1Revenue * 1.5) / 1000000).toFixed(1)}M to cover 18-24 months runway. Allocation: 40% engineering & product development, 30% sales & marketing, 15% operations, 15% reserve. Key hires: Technical co-founder/CTO, 2-3 engineers, marketing lead, 1-2 sales reps. Consider bootstrapping initially if possible, then seek seed funding after achieving early traction metrics.`;
      addWrappedText(funding);
      yPos += 5;
      
      checkAddPage();
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("Success Metrics & KPIs", margin, yPos);
      yPos += 10;
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      const kpis = `Track these metrics monthly: (1) User Growth - Target ${assumptions.users?.includes('SaaS') ? '100' : '500'} signups in first 3 months, (2) Activation Rate - 40%+ of signups should complete onboarding, (3) Revenue - Achieve $10K MRR by month 6, (4) Customer Acquisition Cost - Keep below $${cac}, (5) Churn Rate - Maintain below 7% monthly, (6) Net Promoter Score - Target 40+ within first year. Review and adjust targets quarterly.`;
      addWrappedText(kpis);

      // ========== PAGE 17-18: NEXT STEPS & TIMELINE ==========
      doc.addPage();
      yPos = 20;
      
      doc.setFontSize(20);
      doc.setFont("helvetica", "bold");
      doc.text("Implementation Timeline", margin, yPos);
      yPos += 15;
      
      const timeline = [
        { phase: "Month 1-2: Validation & Planning", tasks: "Conduct 20+ customer interviews, Finalize MVP requirements, Create technical architecture, Register business entity, Set up development environment" },
        { phase: "Month 3-4: MVP Development", tasks: "Build core features, Implement authentication & payments, Design user interface, Set up analytics tracking, Conduct internal testing" },
        { phase: "Month 5-6: Beta Launch", tasks: "Recruit 50-100 beta users, Gather feedback and iterate, Fix critical bugs, Optimize onboarding flow, Prepare marketing materials" },
        { phase: "Month 7-9: Public Launch", tasks: "Launch marketing campaigns, Implement referral program, Scale to 500+ users, Hire first team members, Establish customer support" },
        { phase: "Month 10-12: Growth & Scale", tasks: "Achieve product-market fit, Reach revenue targets, Expand feature set, Consider seed funding, Build strategic partnerships" }
      ];
      
      timeline.forEach((item) => {
        checkAddPage(35);
        doc.setFontSize(12);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(79, 70, 229);
        doc.text(item.phase, margin, yPos);
        yPos += 8;
        
        doc.setFontSize(10);
        doc.setFont("helvetica", "normal");
        doc.setTextColor(0, 0, 0);
        addWrappedText(item.tasks, 10);
        yPos += 5;
      });

      // ========== FINAL PAGE: CONCLUSION ==========
      checkAddPage(80);
      doc.setFontSize(18);
      doc.setFont("helvetica", "bold");
      doc.text("Conclusion", margin, yPos);
      yPos += 12;
      
      doc.setFontSize(11);
      doc.setFont("helvetica", "normal");
      const conclusion = `This comprehensive analysis of "${validationData.idea.title}" reveals a ${score >= 75 ? 'highly promising' : score >= 60 ? 'viable' : 'challenging but potentially viable'} business opportunity in the ${validationData.idea.industry} space. With a success score of ${score}/100, the idea demonstrates ${vr.marketScore >= 70 ? 'strong market potential' : 'moderate market opportunity'}, ${vr.competitionScore >= 70 ? 'favorable competitive positioning' : 'manageable competition'}, and ${vr.uniquenessScore >= 70 ? 'significant differentiation' : 'room for differentiation'}.\n\nThe financial projections suggest potential to reach $${(fp.year3Revenue / 1000000).toFixed(2)}M in revenue by year 3, assuming effective execution of the recommended go-to-market strategy. Key success factors include: maintaining focus on target customer needs, rapid iteration based on user feedback, efficient capital allocation, and building a strong founding team.\n\n${score >= 70 ? 'We recommend proceeding with MVP development and customer validation.' : 'We recommend further market validation and product refinement before significant investment.'}\n\nThis report provides a data-driven foundation for decision-making. Remember that execution, timing, and team quality ultimately determine success. Regular review and adjustment of strategy will be critical as you gather real-world data.`;
      addWrappedText(conclusion);
      
      yPos += 20;
      doc.setFontSize(10);
      doc.setFont("helvetica", "italic");
      doc.setTextColor(100, 100, 100);
      doc.text("Thank you for using VentureIQ. We wish you success in your entrepreneurial journey!", 
        pageWidth / 2, yPos, { align: "center" });

      // Footer on all pages
      const pageCount = doc.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(9);
        doc.setFont("helvetica", "normal");
        doc.setTextColor(128, 128, 128);
        doc.text(
          `VentureIQ Validation Report - ${validationData.idea.title.substring(0, 40)}`,
          margin,
          pageHeight - 10
        );
        doc.text(
          `Page ${i} of ${pageCount}`,
          pageWidth - margin,
          pageHeight - 10,
          { align: "right" }
        );
      }

      // Generate PDF blob
      const pdfBlob = doc.output('blob');
      const pdfUrl = URL.createObjectURL(pdfBlob);
      const fileName = `${validationData.idea.title.replace(/[^a-z0-9]/gi, '_')}_VentureIQ_Report.pdf`;
      
      // Create download link
      const downloadLink = document.createElement('a');
      downloadLink.href = pdfUrl;
      downloadLink.download = fileName;
      downloadLink.style.display = 'none';
      document.body.appendChild(downloadLink);
      
      // Trigger download
      downloadLink.click();
      
      // Cleanup
      setTimeout(() => {
        document.body.removeChild(downloadLink);
        URL.revokeObjectURL(pdfUrl);
      }, 100);
      
      console.log('PDF generated successfully:', fileName);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Failed to generate PDF. Please try again. Error: ' + (error instanceof Error ? error.message : 'Unknown error'));
    }
  };

  const handleNext = async () => {
    const isValid = await form.trigger(
      step === 1 ? ["title", "description", "targetCustomer"] : ["problem", "solution", "businessModel"]
    );
    if (isValid) {
      setStep(2);
    }
  };

  if (validationData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 dark:from-gray-900 dark:via-black dark:to-purple-950 py-12 px-4">
        <div className="container mx-auto max-w-7xl">
          <ResultsDashboard data={validationData} onDownloadPDF={handleDownloadPDF} />
          
          <div className="mt-8 text-center">
            <Button
              onClick={() => {
                setValidationData(null);
                setStep(1);
                form.reset();
              }}
              variant="outline"
              size="lg"
            >
              Validate Another Idea
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (isValidating) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 dark:from-gray-900 dark:via-black dark:to-purple-950 flex items-center justify-center px-4">
        <div className="max-w-2xl w-full bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-8">
          <ValidationProgress currentStep={validationStep} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 dark:from-gray-900 dark:via-black dark:to-purple-950 py-12 px-4">
      <div className="container mx-auto max-w-3xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              VentureIQ Validator
            </span>
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-400">
            Get AI-powered validation of your business idea in minutes
          </p>
        </div>

        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-center gap-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold ${
              step >= 1 ? "bg-indigo-600 text-white" : "bg-gray-300 dark:bg-gray-700 text-gray-600 dark:text-gray-400"
            }`}>
              1
            </div>
            <div className={`w-16 h-1 ${step >= 2 ? "bg-indigo-600" : "bg-gray-300 dark:bg-gray-700"}`} />
            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold ${
              step >= 2 ? "bg-indigo-600 text-white" : "bg-gray-300 dark:bg-gray-700 text-gray-600 dark:text-gray-400"
            }`}>
              2
            </div>
          </div>
          <div className="flex justify-between mt-2 text-sm text-gray-600 dark:text-gray-400">
            <span className="ml-4">Basic Info</span>
            <span className="mr-4">Problem & Solution</span>
          </div>
        </div>

        {/* Form */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-8">
          <form onSubmit={form.handleSubmit(onSubmit)}>
            {step === 1 && <IdeaFormStep1 form={form} />}
            {step === 2 && <IdeaFormStep2 form={form} />}

            <div className="flex justify-between mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
              {step === 2 && (
                <Button
                  type="button"
                  onClick={() => setStep(1)}
                  variant="outline"
                  size="lg"
                >
                  Back
                </Button>
              )}
              
              <div className="ml-auto">
                {step === 1 ? (
                  <Button type="button" onClick={handleNext} size="lg">
                    Next Step
                  </Button>
                ) : (
                  <Button type="submit" size="lg" className="bg-gradient-to-r from-indigo-600 to-purple-600">
                    🚀 Validate My Idea
                  </Button>
                )}
              </div>
            </div>
          </form>
        </div>

        {/* Footer Note */}
        <div className="mt-8 text-center text-sm text-gray-600 dark:text-gray-400">
          <p>Your data is processed securely. We analyze competitors, market trends, and generate financial projections tailored to your business model.</p>
        </div>
      </div>
    </div>
  );
}