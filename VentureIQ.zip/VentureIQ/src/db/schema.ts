import { sqliteTable, integer, text } from 'drizzle-orm/sqlite-core';

// Ideas table - core business idea submissions
export const ideas = sqliteTable('ideas', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  userIdentifier: text('user_identifier').notNull(),
  title: text('title').notNull(),
  description: text('description').notNull(),
  industry: text('industry').notNull(),
  targetCustomer: text('target_customer').notNull(),
  problem: text('problem').notNull(),
  solution: text('solution').notNull(),
  businessModel: text('business_model').notNull(),
  createdAt: text('created_at').notNull(),
});

// Validation results table - AI-powered validation scores
export const validationResults = sqliteTable('validation_results', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  ideaId: integer('idea_id').notNull().references(() => ideas.id),
  successScore: integer('success_score').notNull(),
  marketScore: integer('market_score').notNull(),
  competitionScore: integer('competition_score').notNull(),
  uniquenessScore: integer('uniqueness_score').notNull(),
  timingScore: integer('timing_score').notNull(),
  reasoning: text('reasoning').notNull(),
  dataQuality: text('data_quality').notNull(),
  createdAt: text('created_at').notNull(),
});

// Competitors table - competitive analysis data
export const competitors = sqliteTable('competitors', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  ideaId: integer('idea_id').notNull().references(() => ideas.id),
  name: text('name').notNull(),
  website: text('website'),
  pricing: text('pricing'),
  features: text('features'),
  positioning: text('positioning'),
  marketGap: text('market_gap'),
  createdAt: text('created_at').notNull(),
});

// Market research table - market analysis data
export const marketResearch = sqliteTable('market_research', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  ideaId: integer('idea_id').notNull().references(() => ideas.id),
  marketSize: text('market_size').notNull(),
  industryTrends: text('industry_trends').notNull(),
  customerNeeds: text('customer_needs').notNull(),
  entryBarriers: text('entry_barriers').notNull(),
  createdAt: text('created_at').notNull(),
});

// Financial projections table - revenue forecasting
export const financialProjections = sqliteTable('financial_projections', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  ideaId: integer('idea_id').notNull().references(() => ideas.id),
  assumptions: text('assumptions', { mode: 'json' }).notNull(),
  year1Revenue: integer('year1_revenue').notNull(),
  year2Revenue: integer('year2_revenue').notNull(),
  year3Revenue: integer('year3_revenue').notNull(),
  monthlyBreakdown: text('monthly_breakdown', { mode: 'json' }).notNull(),
  createdAt: text('created_at').notNull(),
});