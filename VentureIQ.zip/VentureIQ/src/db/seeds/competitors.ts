import { db } from '@/db';
import { competitors } from '@/db/schema';

async function main() {
    const sampleCompetitors = [
        // Competitors for TaskFlow AI (ideaId: 1)
        {
            ideaId: 1,
            name: 'Asana',
            website: 'https://asana.com',
            pricing: 'Free for basic, $10.99/user/month Premium, $24.99/user/month Business',
            features: 'Task management, project timelines, workload view, custom fields, portfolio management, advanced reporting',
            positioning: 'Work management platform for teams to organize, track, and manage their work',
            marketGap: 'Lacks AI-powered predictive analytics and automated task prioritization based on team patterns',
            createdAt: new Date('2024-01-16T10:30:00Z').toISOString(),
        },
        {
            ideaId: 1,
            name: 'Monday.com',
            website: 'https://monday.com',
            pricing: '$8/user/month Basic, $10/user/month Standard, $16/user/month Pro',
            features: 'Customizable workflows, automation, integrations, dashboards, time tracking, Gantt charts',
            positioning: 'Visual work operating system for teams to run projects and workflows',
            marketGap: 'Limited AI capabilities, no predictive delay alerts or intelligent resource allocation',
            createdAt: new Date('2024-01-16T10:35:00Z').toISOString(),
        },
        {
            ideaId: 1,
            name: 'ClickUp',
            website: 'https://clickup.com',
            pricing: 'Free forever plan, $5/user/month Unlimited, $12/user/month Business',
            features: 'All-in-one: docs, tasks, goals, chat, whiteboards, time tracking, automations',
            positioning: 'One app to replace them all - comprehensive project management',
            marketGap: 'Complex interface with steep learning curve, AI features are basic add-ons not core to product',
            createdAt: new Date('2024-01-16T10:40:00Z').toISOString(),
        },
        // Competitors for EcoThreads (ideaId: 2)
        {
            ideaId: 2,
            name: 'Rent the Runway',
            website: 'https://renttherunway.com',
            pricing: '$89-$235/month subscription, one-time rentals $30-$100',
            features: 'Designer clothing rental, dry cleaning included, unlimited swaps, reserve items, styling service',
            positioning: 'Designer fashion rental subscription service',
            marketGap: 'Focus only on high-end designer wear, no resale marketplace, no sustainability metrics or carbon tracking',
            createdAt: new Date('2024-01-17T14:20:00Z').toISOString(),
        },
        {
            ideaId: 2,
            name: 'ThredUp',
            website: 'https://thredup.com',
            pricing: 'Commission-based resale (sellers get 5-80% of sale price)',
            features: 'Online consignment store, clean-out kits, quality standards, broad selection',
            positioning: 'World\'s largest online thrift store and fashion resale marketplace',
            marketGap: 'Resale only (no rental option), doesn\'t focus on sustainable/eco brands specifically, no carbon footprint tracking',
            createdAt: new Date('2024-01-17T14:25:00Z').toISOString(),
        },
        {
            ideaId: 2,
            name: 'Poshmark',
            website: 'https://poshmark.com',
            pricing: 'Free to list, 20% commission on sales over $15',
            features: 'Social commerce platform, peer-to-peer marketplace, virtual shopping parties',
            positioning: 'Social marketplace for new and secondhand fashion',
            marketGap: 'No focus on sustainability, no rental model, no brand curation or verification, no environmental impact tracking',
            createdAt: new Date('2024-01-17T14:30:00Z').toISOString(),
        },
        // Competitors for NutriScan AI (ideaId: 3)
        {
            ideaId: 3,
            name: 'MyFitnessPal',
            website: 'https://myfitnesspal.com',
            pricing: 'Free basic, $9.99/month Premium',
            features: 'Manual food logging, barcode scanning, largest food database, exercise tracking, macro tracking',
            positioning: 'World\'s #1 nutrition and food tracking app',
            marketGap: 'Requires manual entry (high friction), no computer vision, no personalized health condition recommendations, no dietitian access',
            createdAt: new Date('2024-01-18T09:15:00Z').toISOString(),
        },
        {
            ideaId: 3,
            name: 'Noom',
            website: 'https://noom.com',
            pricing: '$59/month, $99 for 2 months, $129 for 4 months',
            features: 'Psychology-based weight loss, food logging, coaching, educational content, behavior change focus',
            positioning: 'Weight loss program combining psychology, technology, and human coaching',
            marketGap: 'Focus only on weight loss, expensive, still requires manual food entry, no photo-based AI analysis, limited to weight management vs. broader health conditions',
            createdAt: new Date('2024-01-18T09:20:00Z').toISOString(),
        },
        {
            ideaId: 3,
            name: 'Foodvisor',
            website: 'https://foodvisor.io',
            pricing: 'Free basic, $9.99/month Premium',
            features: 'AI food photo recognition, nutrition tracking, meal plans, water tracking',
            positioning: 'AI-powered nutrition app with image recognition',
            marketGap: 'Generic recommendations (not personalized for medical conditions), no integration with health devices, no dietitian consultations, less comprehensive than NutriScan\'s health profile approach',
            createdAt: new Date('2024-01-18T09:25:00Z').toISOString(),
        },
    ];

    await db.insert(competitors).values(sampleCompetitors);
    
    console.log('✅ Competitors seeder completed successfully');
}

main().catch((error) => {
    console.error('❌ Seeder failed:', error);
});