import { db } from '@/db';
import { financialProjections } from '@/db/schema';

async function main() {
    const sampleFinancialProjections = [
        {
            ideaId: 1,
            assumptions: JSON.stringify({
                pricingTiers: {
                    free: "$0",
                    team: "$15/user/month",
                    enterprise: "$25/user/month"
                },
                conversionRates: {
                    freeToTeam: "8%",
                    teamToEnterprise: "12%"
                },
                churnRate: "5.5% monthly",
                averageTeamSize: 12,
                salesCycle: "45 days",
                CAC: "$180 per customer",
                LTV: "$3,240",
                ltv_cac_ratio: "18:1"
            }),
            year1Revenue: 420000,
            year2Revenue: 1680000,
            year3Revenue: 4620000,
            monthlyBreakdown: JSON.stringify({
                month1: 5000,
                month2: 8000,
                month3: 12000,
                month4: 18000,
                month5: 24000,
                month6: 30000,
                month7: 35000,
                month8: 38000,
                month9: 42000,
                month10: 48000,
                month11: 70000,
                month12: 90000
            }),
            createdAt: new Date('2024-01-15T10:30:00Z').toISOString(),
        },
        {
            ideaId: 2,
            assumptions: JSON.stringify({
                revenueStreams: {
                    directSalesCommission: "15%",
                    rentalSubscription: "$59/month",
                    resaleCommission: "20%",
                    carbonOffset: "$2.99/order"
                },
                userMix: {
                    directBuyers: "45%",
                    rentalSubscribers: "30%",
                    resaleSellers: "25%"
                },
                averageOrderValue: "$85",
                monthlyActiveUsers: "year1: 2400, year2: 12000, year3: 38000",
                churnRate: "8% monthly for rental",
                CAC: "$65",
                inventoryCost: "40% of revenue",
                logisticsCost: "$6.50 per rental cycle"
            }),
            year1Revenue: 580000,
            year2Revenue: 2340000,
            year3Revenue: 6780000,
            monthlyBreakdown: JSON.stringify({
                month1: 8000,
                month2: 12000,
                month3: 18000,
                month4: 28000,
                month5: 35000,
                month6: 42000,
                month7: 48000,
                month8: 52000,
                month9: 58000,
                month10: 68000,
                month11: 95000,
                month12: 116000
            }),
            createdAt: new Date('2024-01-16T14:20:00Z').toISOString(),
        },
        {
            ideaId: 3,
            assumptions: JSON.stringify({
                pricingTiers: {
                    free: "$0",
                    premium: "$12.99/month",
                    premiumPlus: "$29.99/month with dietitian"
                },
                conversionRates: {
                    freeToPremium: "12%",
                    premiumToPremiumPlus: "18%"
                },
                userAcquisition: {
                    organic: "40%",
                    paid: "45%",
                    referral: "15%"
                },
                churnRate: "6.5% monthly",
                averageLifetimeMonths: 14,
                CAC: "$16",
                LTV: "$182",
                ltv_cac_ratio: "11.4:1",
                appStoreRating: "4.6 target",
                viralCoefficient: "0.35"
            }),
            year1Revenue: 780000,
            year2Revenue: 3900000,
            year3Revenue: 11700000,
            monthlyBreakdown: JSON.stringify({
                month1: 12000,
                month2: 22000,
                month3: 35000,
                month4: 45000,
                month5: 55000,
                month6: 62000,
                month7: 68000,
                month8: 72000,
                month9: 78000,
                month10: 85000,
                month11: 118000,
                month12: 128000
            }),
            createdAt: new Date('2024-01-17T09:45:00Z').toISOString(),
        }
    ];

    await db.insert(financialProjections).values(sampleFinancialProjections);
    
    console.log('✅ Financial projections seeder completed successfully');
}

main().catch((error) => {
    console.error('❌ Seeder failed:', error);
});