import { db } from '@/db';
import { ideas } from '@/db/schema';

async function main() {
    const now = new Date();
    const threeDaysAgo = new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000);
    const fiveDaysAgo = new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000);
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    const sampleIdeas = [
        {
            userIdentifier: 'user_demo_001',
            title: 'TaskFlow AI - Intelligent Project Management',
            description: 'AI-powered project management tool that automatically prioritizes tasks, predicts project delays, and suggests optimal resource allocation for teams of 5-50 people',
            industry: 'SaaS / Productivity Software',
            targetCustomer: 'Small to mid-sized tech companies, remote-first startups, and digital agencies with 5-50 employees',
            problem: 'Project managers waste 20+ hours per week on task prioritization, status updates, and resource allocation. Teams lack visibility into project risks and bottlenecks until it\'s too late',
            solution: 'AI assistant that integrates with existing tools (Jira, Asana, Slack) to analyze team patterns, predict delays, auto-prioritize tasks based on dependencies and team capacity, and provide real-time risk alerts',
            businessModel: 'Freemium SaaS: Free for up to 5 users, $15/user/month for teams, $25/user/month for enterprise with advanced AI features and custom integrations',
            createdAt: threeDaysAgo.toISOString(),
        },
        {
            userIdentifier: 'user_demo_002',
            title: 'EcoThreads - Circular Fashion Marketplace',
            description: 'Online marketplace connecting sustainable fashion brands with conscious consumers, featuring a unique clothing rental and resale program with carbon footprint tracking',
            industry: 'E-commerce / Sustainable Fashion',
            targetCustomer: 'Environmentally conscious millennials and Gen-Z consumers (ages 22-35) earning $40K-$80K annually, primarily in urban areas',
            problem: 'Fast fashion generates 92 million tons of waste annually. Conscious consumers want sustainable options but struggle to find affordable, stylish eco-friendly clothing. Existing sustainable brands are expensive and lack variety',
            solution: 'Curated marketplace of verified sustainable brands with rental options (wear items 3-5 times then return), resale program with trade-in credits, and real-time carbon footprint calculator showing environmental impact of each purchase',
            businessModel: 'Hybrid model: 15% commission on direct sales, subscription rental service at $59/month for 4 items, 20% commission on resale transactions, plus $2.99 carbon offset add-on per order',
            createdAt: fiveDaysAgo.toISOString(),
        },
        {
            userIdentifier: 'user_demo_003',
            title: 'NutriScan AI - Personalized Nutrition Coach',
            description: 'Mobile app using computer vision to analyze food photos and provide real-time personalized nutrition recommendations based on user health goals, allergies, and medical conditions',
            industry: 'Healthtech / Mobile Apps',
            targetCustomer: 'Health-conscious adults (ages 25-55) managing chronic conditions (diabetes, hypertension, weight loss), fitness enthusiasts, and people with dietary restrictions. Primary market: US, UK, Australia',
            problem: '67% of adults struggle to maintain healthy eating habits. Manual calorie tracking apps have 80% abandonment rate within 3 months. People with health conditions lack affordable, personalized nutrition guidance between doctor visits',
            solution: 'Snap photo of meal, AI instantly identifies foods, calculates nutritional content, flags allergens, and provides personalized recommendations based on health profile. Integrates with Apple Health, Fitbit, glucose monitors. Weekly video consultations with registered dietitians',
            businessModel: 'Freemium mobile app: Free basic food scanning, $12.99/month for unlimited scans + AI recommendations + health tracking, $29.99/month premium tier adds monthly dietitian consultations and meal planning',
            createdAt: sevenDaysAgo.toISOString(),
        },
    ];

    await db.insert(ideas).values(sampleIdeas);
    
    console.log('✅ Ideas seeder completed successfully');
}

main().catch((error) => {
    console.error('❌ Seeder failed:', error);
});