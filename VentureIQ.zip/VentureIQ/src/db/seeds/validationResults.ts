import { db } from '@/db';
import { validationResults } from '@/db/schema';

async function main() {
    const sampleValidationResults = [
        {
            ideaId: 1,
            successScore: 78,
            marketScore: 85,
            competitionScore: 65,
            uniquenessScore: 72,
            timingScore: 88,
            reasoning: "Strong product-market fit in the growing project management SaaS market ($6.8B in 2023). The AI-powered prediction and automation features provide meaningful differentiation from existing tools. Major strengths: clear target market, proven willingness to pay for PM tools, strong integration strategy. Concerns: highly competitive space requires significant marketing budget, feature parity race with established players. The freemium model is proven but customer acquisition cost may be high. Remote work trends and AI adoption make timing excellent.",
            dataQuality: "High - detailed problem statement, well-defined target market, specific pricing strategy, clear competitive differentiation",
            createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
            ideaId: 2,
            successScore: 71,
            marketScore: 79,
            competitionScore: 58,
            uniquenessScore: 68,
            timingScore: 82,
            reasoning: "Addresses a real problem in the $100B+ global fashion resale market with strong ESG tailwinds. The hybrid rental-resale model with carbon tracking is innovative. Strengths: clear target demographic, multiple revenue streams, mission-driven brand appeal. Challenges: complex inventory management, logistics costs for rental returns, need for supplier relationships, customer lifetime value depends on retention. Market timing is strong with 73% of millennials willing to pay more for sustainable products. Biggest risk is operational complexity and unit economics of rental model.",
            dataQuality: "Medium-High - clear problem and solution, specific target market, detailed business model, but lacks operational detail on logistics and inventory management",
            createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
            ideaId: 3,
            successScore: 82,
            marketScore: 91,
            competitionScore: 70,
            uniquenessScore: 75,
            timingScore: 85,
            reasoning: "Exceptional market opportunity in the $4.2T global wellness market with strong tailwinds from chronic disease management needs. Computer vision eliminates the #1 friction point in nutrition tracking (manual entry). Strengths: solves real pain point with 80% app abandonment rate, integration with health devices creates sticky ecosystem, dietitian consultations add credibility and retention. Target market of people managing health conditions provides strong willingness to pay. Risks: accuracy of AI food recognition is critical (must be 90%+ to build trust), healthcare data privacy compliance required, insurance partnerships could accelerate but take time. Premium pricing at $29.99/month is validated by Noom's success at similar price point.",
            dataQuality: "High - comprehensive problem definition, specific target market with demographics, clear value proposition, validated pricing strategy, integration strategy detailed",
            createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        }
    ];

    await db.insert(validationResults).values(sampleValidationResults);
    
    console.log('✅ Validation results seeder completed successfully');
}

main().catch((error) => {
    console.error('❌ Seeder failed:', error);
});