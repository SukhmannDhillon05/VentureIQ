"use client";

import { UseFormReturn } from "react-hook-form";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

interface IdeaFormData {
  title: string;
  description: string;
  targetCustomer: string;
  problem: string;
  solution: string;
  businessModel: string;
}

interface Step1Props {
  form: UseFormReturn<IdeaFormData>;
}

export const IdeaFormStep1 = ({ form }: Step1Props) => {
  const { register, formState: { errors } } = form;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Describe Your Business Idea
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          Start by giving us a brief overview of what you're building
        </p>
      </div>

      <div className="space-y-4">
        <div>
          <Label htmlFor="title">Idea Title *</Label>
          <Input
            id="title"
            {...register("title")}
            placeholder="e.g., TaskFlow AI - Intelligent Project Management"
            className="mt-1"
          />
          {errors.title && (
            <p className="text-sm text-red-600 mt-1">{errors.title.message}</p>
          )}
        </div>

        <div>
          <Label htmlFor="description">Brief Description *</Label>
          <Textarea
            id="description"
            {...register("description")}
            placeholder="Describe your business idea in 2-3 sentences. What does it do?"
            rows={4}
            className="mt-1"
          />
          {errors.description && (
            <p className="text-sm text-red-600 mt-1">{errors.description.message}</p>
          )}
          <p className="text-sm text-gray-500 mt-1">
            Be specific about what your product/service does
          </p>
        </div>

        <div>
          <Label htmlFor="targetCustomer">Target Customer *</Label>
          <Textarea
            id="targetCustomer"
            {...register("targetCustomer")}
            placeholder="e.g., Small to mid-sized tech companies with 5-50 employees, primarily remote-first startups"
            rows={3}
            className="mt-1"
          />
          {errors.targetCustomer && (
            <p className="text-sm text-red-600 mt-1">{errors.targetCustomer.message}</p>
          )}
          <p className="text-sm text-gray-500 mt-1">
            Who is your ideal customer? Be specific about demographics, company size, industry, etc.
          </p>
        </div>
      </div>
    </div>
  );
};
