"use client";

import { UseFormReturn } from "react-hook-form";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface IdeaFormData {
  title: string;
  description: string;
  targetCustomer: string;
  problem: string;
  solution: string;
  businessModel: string;
}

interface Step2Props {
  form: UseFormReturn<IdeaFormData>;
}

export const IdeaFormStep2 = ({ form }: Step2Props) => {
  const { register, formState: { errors } } = form;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Problem & Solution
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          What problem are you solving and how?
        </p>
      </div>

      <div className="space-y-4">
        <div>
          <Label htmlFor="problem">Problem Statement *</Label>
          <Textarea
            id="problem"
            {...register("problem")}
            placeholder="Describe the specific problem your target customers face. What pain points, frustrations, or inefficiencies do they experience?"
            rows={4}
            className="mt-1"
          />
          {errors.problem && (
            <p className="text-sm text-red-600 mt-1">{errors.problem.message}</p>
          )}
          <p className="text-sm text-gray-500 mt-1">
            Be specific about the current situation and why it's a problem
          </p>
        </div>

        <div>
          <Label htmlFor="solution">Your Solution *</Label>
          <Textarea
            id="solution"
            {...register("solution")}
            placeholder="How does your product/service solve this problem? What makes your approach unique or better?"
            rows={4}
            className="mt-1"
          />
          {errors.solution && (
            <p className="text-sm text-red-600 mt-1">{errors.solution.message}</p>
          )}
          <p className="text-sm text-gray-500 mt-1">
            Explain your approach and key features that address the problem
          </p>
        </div>

        <div>
          <Label htmlFor="businessModel">Business Model *</Label>
          <Textarea
            id="businessModel"
            {...register("businessModel")}
            placeholder="e.g., Freemium SaaS: Free for up to 5 users, $15/user/month for teams, $25/user/month for enterprise"
            rows={3}
            className="mt-1"
          />
          {errors.businessModel && (
            <p className="text-sm text-red-600 mt-1">{errors.businessModel.message}</p>
          )}
          <p className="text-sm text-gray-500 mt-1">
            How will you make money? Include pricing tiers, revenue streams, etc.
          </p>
        </div>
      </div>
    </div>
  );
};
