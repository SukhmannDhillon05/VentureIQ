"use client";

import { useState, useEffect } from "react";
import { Loader2 } from "lucide-react";

interface ProgressStep {
  label: string;
  status: "pending" | "active" | "completed";
}

interface ValidationProgressProps {
  currentStep: number;
}

export const ValidationProgress = ({ currentStep }: ValidationProgressProps) => {
  const [steps, setSteps] = useState<ProgressStep[]>([
    { label: "Parsing business idea", status: "pending" },
    { label: "Finding competitors", status: "pending" },
    { label: "Analyzing market", status: "pending" },
    { label: "Calculating financials", status: "pending" },
    { label: "Predicting success", status: "pending" },
  ]);

  useEffect(() => {
    setSteps(prev => 
      prev.map((step, idx) => ({
        ...step,
        status: idx < currentStep ? "completed" : idx === currentStep ? "active" : "pending"
      }))
    );
  }, [currentStep]);

  return (
    <div className="space-y-4">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Analyzing Your Business Idea
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          This will take about 10-15 seconds
        </p>
      </div>

      <div className="space-y-3">
        {steps.map((step, idx) => (
          <div key={idx} className="flex items-center gap-3">
            <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
              step.status === "completed" ? "bg-green-500" :
              step.status === "active" ? "bg-indigo-600" :
              "bg-gray-300 dark:bg-gray-700"
            }`}>
              {step.status === "active" && (
                <Loader2 className="w-5 h-5 text-white animate-spin" />
              )}
              {step.status === "completed" && (
                <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              )}
              {step.status === "pending" && (
                <div className="w-3 h-3 rounded-full bg-gray-400 dark:bg-gray-600" />
              )}
            </div>
            <span className={`text-lg ${
              step.status === "active" ? "text-indigo-600 dark:text-indigo-400 font-semibold" :
              step.status === "completed" ? "text-gray-700 dark:text-gray-300" :
              "text-gray-500 dark:text-gray-500"
            }`}>
              {step.label}
            </span>
          </div>
        ))}
      </div>

      <div className="mt-8 p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg">
        <p className="text-sm text-indigo-700 dark:text-indigo-300">
          💡 <strong>Pro Tip:</strong> We're analyzing real competitor data, market trends, and generating financial projections tailored to your specific business model.
        </p>
      </div>
    </div>
  );
};
