"use client";

import { useState } from "react";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Download, TrendingUp, Users, DollarSign, Target } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ValidationData {
  idea: {
    id: number;
    title: string;
    description: string;
    industry: string;
    targetCustomer: string;
    problem: string;
    solution: string;
    businessModel: string;
  };
  validationResults: Array<{
    successScore: number;
    marketScore: number;
    competitionScore: number;
    uniquenessScore: number;
    timingScore: number;
    reasoning: string;
  }>;
  competitors: Array<{
    name: string;
    website: string;
    pricing: string;
    features: string;
    positioning: string;
    marketGap: string;
  }>;
  marketResearch: {
    marketSize: string;
    industryTrends: string;
    customerNeeds: string;
    entryBarriers: string;
  } | null;
  financialProjections: {
    assumptions: any;
    year1Revenue: number;
    year2Revenue: number;
    year3Revenue: number;
    monthlyBreakdown: any;
  } | null;
}

interface ResultsDashboardProps {
  data: ValidationData;
  onDownloadPDF: () => void;
}

export const ResultsDashboard = ({ data, onDownloadPDF }: ResultsDashboardProps) => {
  const [activeTab, setActiveTab] = useState<"overview" | "competitors" | "market" | "financials">("overview");

  const validation = data.validationResults[0];
  const scoreData = [
    { name: "Market", value: validation.marketScore, color: "#8B5CF6" },
    { name: "Competition", value: validation.competitionScore, color: "#3B82F6" },
    { name: "Uniqueness", value: validation.uniquenessScore, color: "#10B981" },
    { name: "Timing", value: validation.timingScore, color: "#F59E0B" },
  ];

  const revenueData = data.financialProjections ? [
    { year: "Year 1", revenue: data.financialProjections.year1Revenue },
    { year: "Year 2", revenue: data.financialProjections.year2Revenue },
    { year: "Year 3", revenue: data.financialProjections.year3Revenue },
  ] : [];

  const monthlyData = data.financialProjections?.monthlyBreakdown ? 
    Object.entries(data.financialProjections.monthlyBreakdown).map(([month, revenue]) => ({
      month: month.replace('month', 'M'),
      revenue: revenue as number
    })) : [];

  const getScoreColor = (score: number) => {
    if (score >= 75) return "text-green-600 dark:text-green-400";
    if (score >= 60) return "text-yellow-600 dark:text-yellow-400";
    return "text-red-600 dark:text-red-400";
  };

  const getScoreBg = (score: number) => {
    if (score >= 75) return "bg-green-100 dark:bg-green-900/30";
    if (score >= 60) return "bg-yellow-100 dark:bg-yellow-900/30";
    return "bg-red-100 dark:bg-red-900/30";
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
              {data.idea.title}
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              {data.idea.industry}
            </p>
          </div>
          <Button onClick={onDownloadPDF} size="lg" className="gap-2">
            <Download className="w-5 h-5" />
            Download PDF Report
          </Button>
        </div>
      </div>

      {/* Success Score Card */}
      <div className={`${getScoreBg(validation.successScore)} rounded-2xl shadow-lg p-8 text-center`}>
        <div className="inline-flex items-center justify-center w-32 h-32 rounded-full bg-white dark:bg-gray-800 shadow-lg mb-4">
          <div>
            <div className={`text-5xl font-bold ${getScoreColor(validation.successScore)}`}>
              {validation.successScore}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">/ 100</div>
          </div>
        </div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Success Prediction Score
        </h2>
        <p className="text-gray-700 dark:text-gray-300 max-w-2xl mx-auto">
          {validation.successScore >= 75 ? "Strong potential! Your idea shows excellent fundamentals across key success factors." :
           validation.successScore >= 60 ? "Promising opportunity with some areas to refine for better market fit." :
           "Challenging path ahead. Consider pivoting or addressing key weaknesses."}
        </p>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg overflow-hidden">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="flex -mb-px">
            {[
              { id: "overview", label: "Overview", icon: Target },
              { id: "competitors", label: "Competitors", icon: Users },
              { id: "market", label: "Market", icon: TrendingUp },
              { id: "financials", label: "Financials", icon: DollarSign },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 py-4 px-6 text-center border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? "border-indigo-600 text-indigo-600 dark:text-indigo-400"
                    : "border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                }`}
              >
                <div className="flex items-center justify-center gap-2">
                  <tab.icon className="w-5 h-5" />
                  {tab.label}
                </div>
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {/* Overview Tab */}
          {activeTab === "overview" && (
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                {/* Score Breakdown */}
                <div>
                  <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Score Breakdown</h3>
                  <div className="space-y-3">
                    {scoreData.map((item) => (
                      <div key={item.name}>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{item.name}</span>
                          <span className="text-sm font-semibold text-gray-900 dark:text-white">{item.value}/100</span>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                          <div
                            className="h-2 rounded-full transition-all"
                            style={{ width: `${item.value}%`, backgroundColor: item.color }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Score Distribution */}
                <div>
                  <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Score Distribution</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie
                        data={scoreData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, value }) => `${name}: ${value}`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {scoreData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* AI Reasoning */}
              <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-6">
                <h3 className="text-lg font-bold mb-3 text-gray-900 dark:text-white">
                  🤖 AI Analysis
                </h3>
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed whitespace-pre-line">
                  {validation.reasoning}
                </p>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-indigo-50 dark:bg-indigo-900/30 rounded-lg p-4">
                  <div className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">
                    {data.competitors.length}
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Competitors Found</div>
                </div>
                <div className="bg-green-50 dark:bg-green-900/30 rounded-lg p-4">
                  <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                    ${(data.financialProjections?.year3Revenue || 0) / 1000000}M
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Year 3 Revenue</div>
                </div>
                <div className="bg-purple-50 dark:bg-purple-900/30 rounded-lg p-4">
                  <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                    {validation.uniquenessScore}%
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Uniqueness</div>
                </div>
                <div className="bg-orange-50 dark:bg-orange-900/30 rounded-lg p-4">
                  <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">
                    {validation.timingScore}%
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Market Timing</div>
                </div>
              </div>
            </div>
          )}

          {/* Competitors Tab */}
          {activeTab === "competitors" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">
                  Competitive Landscape ({data.competitors.length} competitors found)
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  We've identified the following competitors and analyzed their market positioning
                </p>
              </div>

              <div className="space-y-4">
                {data.competitors.map((competitor, idx) => (
                  <div key={idx} className="border border-gray-200 dark:border-gray-700 rounded-lg p-6 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h4 className="text-lg font-bold text-gray-900 dark:text-white">{competitor.name}</h4>
                        {competitor.website && (
                          <a href={competitor.website} target="_blank" rel="noopener noreferrer" className="text-sm text-indigo-600 dark:text-indigo-400 hover:underline">
                            {competitor.website}
                          </a>
                        )}
                      </div>
                      <span className="px-3 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-sm font-medium text-gray-700 dark:text-gray-300">
                        Competitor #{idx + 1}
                      </span>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">Pricing:</span>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{competitor.pricing}</p>
                      </div>
                      <div>
                        <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">Features:</span>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{competitor.features}</p>
                      </div>
                      <div>
                        <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">Positioning:</span>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{competitor.positioning}</p>
                      </div>
                      <div>
                        <span className="text-sm font-semibold text-green-700 dark:text-green-400">Market Gap:</span>
                        <p className="text-sm text-green-600 dark:text-green-400 mt-1">{competitor.marketGap}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Market Tab */}
          {activeTab === "market" && data.marketResearch && (
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-blue-50 dark:bg-blue-900/30 rounded-lg p-6">
                  <h4 className="text-lg font-bold text-blue-900 dark:text-blue-300 mb-3">📊 Market Size</h4>
                  <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed">
                    {data.marketResearch.marketSize}
                  </p>
                </div>

                <div className="bg-purple-50 dark:bg-purple-900/30 rounded-lg p-6">
                  <h4 className="text-lg font-bold text-purple-900 dark:text-purple-300 mb-3">📈 Industry Trends</h4>
                  <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed">
                    {data.marketResearch.industryTrends}
                  </p>
                </div>

                <div className="bg-green-50 dark:bg-green-900/30 rounded-lg p-6">
                  <h4 className="text-lg font-bold text-green-900 dark:text-green-300 mb-3">🎯 Customer Needs</h4>
                  <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed">
                    {data.marketResearch.customerNeeds}
                  </p>
                </div>

                <div className="bg-orange-50 dark:bg-orange-900/30 rounded-lg p-6">
                  <h4 className="text-lg font-bold text-orange-900 dark:text-orange-300 mb-3">🚧 Entry Barriers</h4>
                  <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed">
                    {data.marketResearch.entryBarriers}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Financials Tab */}
          {activeTab === "financials" && data.financialProjections && (
            <div className="space-y-6">
              {/* Revenue Projection */}
              <div>
                <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">3-Year Revenue Projection</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={revenueData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis tickFormatter={(value) => `$${value / 1000000}M`} />
                    <Tooltip formatter={(value: number) => `$${(value / 1000000).toFixed(2)}M`} />
                    <Legend />
                    <Bar dataKey="revenue" fill="#8B5CF6" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Monthly Breakdown */}
              <div>
                <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Year 1 Monthly Revenue</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={monthlyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis tickFormatter={(value) => `$${value / 1000}K`} />
                    <Tooltip formatter={(value: number) => `$${(value / 1000).toFixed(1)}K`} />
                    <Legend />
                    <Line type="monotone" dataKey="revenue" stroke="#3B82F6" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Assumptions */}
              <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-6">
                <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-white">📋 Key Assumptions</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {Object.entries(data.financialProjections.assumptions).map(([key, value]) => (
                    <div key={key}>
                      <span className="text-sm font-semibold text-gray-700 dark:text-gray-300 capitalize">
                        {key.replace(/([A-Z])/g, ' $1').trim()}:
                      </span>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{String(value)}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};