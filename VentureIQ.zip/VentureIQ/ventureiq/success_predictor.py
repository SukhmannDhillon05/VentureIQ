"""
Success Predictor Module
Calculates success probability based on multiple factors
"""

from typing import Dict, List
import random

class SuccessPredictor:
    def __init__(self):
        self.weights = {
            'market_size': 0.25,
            'competition': 0.20,
            'uniqueness': 0.20,
            'timing': 0.15,
            'business_model': 0.10,
            'execution': 0.10,
        }
    
    def predict_success(self, 
                       parsed_idea: Dict, 
                       market_data: Dict, 
                       competitors: List[Dict],
                       data_quality: float = 0.8) -> Dict:
        """Calculate success probability score"""
        
        # Calculate component scores
        market_score = self._score_market_size(market_data)
        competition_score = self._score_competition(competitors)
        uniqueness_score = self._score_uniqueness(parsed_idea, competitors)
        timing_score = self._score_timing(market_data)
        business_model_score = self._score_business_model(parsed_idea['business_model'])
        execution_score = self._score_execution_potential(parsed_idea)
        
        # Calculate weighted total
        total_score = (
            market_score * self.weights['market_size'] +
            competition_score * self.weights['competition'] +
            uniqueness_score * self.weights['uniqueness'] +
            timing_score * self.weights['timing'] +
            business_model_score * self.weights['business_model'] +
            execution_score * self.weights['execution']
        )
        
        # Adjust for data quality/confidence
        confidence_adjusted_score = total_score * data_quality
        
        # Add slight randomness for realism (±3%)
        final_score = confidence_adjusted_score + random.uniform(-3, 3)
        final_score = max(min(final_score, 95), 40)  # Clamp between 40-95%
        
        return {
            'overall_score': round(final_score, 1),
            'confidence_level': self._get_confidence_level(data_quality),
            'component_scores': {
                'market_size': round(market_score, 1),
                'competition': round(competition_score, 1),
                'uniqueness': round(uniqueness_score, 1),
                'timing': round(timing_score, 1),
                'business_model': round(business_model_score, 1),
                'execution_potential': round(execution_score, 1),
            },
            'reasoning': self._generate_reasoning(
                final_score, 
                market_score, 
                competition_score, 
                uniqueness_score
            ),
            'risk_factors': self._identify_risks(parsed_idea, market_data, competitors),
            'success_factors': self._identify_success_factors(parsed_idea, market_data),
        }
    
    def _score_market_size(self, market_data: Dict) -> float:
        """Score based on market size (0-100)"""
        size_str = market_data.get('total_market_size', '')
        
        import re
        numbers = re.findall(r'[\d.]+', size_str)
        if numbers:
            value = float(numbers[0])
            
            if 'T' in size_str:
                return 95
            elif 'B' in size_str:
                if value > 200:
                    return 90
                elif value > 100:
                    return 85
                elif value > 50:
                    return 75
                else:
                    return 65
            elif 'M' in size_str:
                if value > 500:
                    return 60
                else:
                    return 50
        
        return 60  # Default
    
    def _score_competition(self, competitors: List[Dict]) -> float:
        """Score based on competition level (0-100, higher = less competition)"""
        num_competitors = len(competitors)
        
        # Fewer competitors = higher score
        if num_competitors <= 3:
            base_score = 85
        elif num_competitors <= 5:
            base_score = 75
        elif num_competitors <= 7:
            base_score = 65
        else:
            base_score = 55
        
        # Adjust based on competitor strength
        strong_competitors = sum(1 for c in competitors 
                                if c.get('funding') and ('Acquired' in c['funding'] or 'Public' in c['funding']))
        
        base_score -= strong_competitors * 5
        
        return max(base_score, 30)
    
    def _score_uniqueness(self, parsed_idea: Dict, competitors: List[Dict]) -> float:
        """Score based on solution uniqueness (0-100)"""
        # Analyze how different the solution is
        solution = parsed_idea.get('solution', '').lower()
        
        # Check for innovation keywords
        innovation_keywords = ['ai', 'ml', 'blockchain', 'innovative', 'unique', 'novel', 'revolutionary']
        innovation_count = sum(1 for keyword in innovation_keywords if keyword in solution)
        
        base_score = 60
        base_score += innovation_count * 5
        
        # If there are many competitors, likely less unique
        if len(competitors) > 7:
            base_score -= 10
        
        return max(min(base_score, 90), 40)
    
    def _score_timing(self, market_data: Dict) -> float:
        """Score based on market timing (0-100)"""
        growth_rate_str = market_data.get('growth_rate', '')
        
        import re
        numbers = re.findall(r'[\d.]+', growth_rate_str)
        if numbers:
            growth_rate = float(numbers[0])
            
            if growth_rate > 20:
                return 90
            elif growth_rate > 15:
                return 80
            elif growth_rate > 10:
                return 70
            elif growth_rate > 5:
                return 60
            else:
                return 50
        
        return 65  # Default
    
    def _score_business_model(self, model: str) -> float:
        """Score based on business model viability (0-100)"""
        model_scores = {
            'subscription': 85,  # Predictable revenue
            'marketplace': 80,   # Network effects
            'saas': 85,          # High margins
            'freemium': 70,      # Challenging conversion
            'ecommerce': 65,     # Competitive
            'advertising': 60,   # Scale required
            'transaction': 75,   # Volume dependent
            'licensing': 70,     # Sales cycle
        }
        
        return model_scores.get(model, 70)
    
    def _score_execution_potential(self, parsed_idea: Dict) -> float:
        """Score execution potential based on idea clarity (0-100)"""
        # More detailed idea = better execution potential
        base_score = 65
        
        if parsed_idea.get('key_features'):
            base_score += 10
        
        if len(parsed_idea.get('solution', '')) > 100:
            base_score += 10
        
        if parsed_idea.get('target_customer') != 'General Consumers':
            base_score += 5  # Specific target = better
        
        return min(base_score, 90)
    
    def _get_confidence_level(self, data_quality: float) -> str:
        """Get confidence level label"""
        if data_quality >= 0.9:
            return 'Very High'
        elif data_quality >= 0.75:
            return 'High'
        elif data_quality >= 0.6:
            return 'Moderate'
        else:
            return 'Low'
    
    def _generate_reasoning(self, total_score: float, market_score: float, 
                           competition_score: float, uniqueness_score: float) -> List[str]:
        """Generate reasoning for the score"""
        reasoning = []
        
        # Overall assessment
        if total_score >= 80:
            reasoning.append("Strong market opportunity with favorable conditions")
        elif total_score >= 70:
            reasoning.append("Promising opportunity with manageable challenges")
        elif total_score >= 60:
            reasoning.append("Viable opportunity requiring careful execution")
        else:
            reasoning.append("Challenging opportunity with significant hurdles")
        
        # Market size reasoning
        if market_score >= 80:
            reasoning.append("Large addressable market provides room for growth")
        elif market_score < 60:
            reasoning.append("Limited market size may constrain growth potential")
        
        # Competition reasoning
        if competition_score >= 75:
            reasoning.append("Moderate competition creates opportunities for differentiation")
        elif competition_score < 60:
            reasoning.append("Highly competitive market requires strong differentiation")
        
        # Uniqueness reasoning
        if uniqueness_score >= 75:
            reasoning.append("Unique approach provides competitive advantage")
        elif uniqueness_score < 60:
            reasoning.append("Solution differentiation needs strengthening")
        
        return reasoning
    
    def _identify_risks(self, parsed_idea: Dict, market_data: Dict, 
                       competitors: List[Dict]) -> List[str]:
        """Identify key risk factors"""
        risks = []
        
        # Competition risks
        if len(competitors) >= 7:
            risks.append("High competition from established players")
        
        strong_competitors = [c for c in competitors 
                            if 'Public' in c.get('funding', '') or 'Acquired' in c.get('funding', '')]
        if len(strong_competitors) >= 2:
            risks.append("Multiple well-funded competitors with resources")
        
        # Market risks
        barriers = market_data.get('entry_barriers', [])
        if len(barriers) >= 3:
            risks.append(f"Significant entry barriers: {', '.join(barriers[:2])}")
        
        pain_points = market_data.get('pain_points', [])
        if pain_points:
            risks.append(f"Industry challenge: {pain_points[0]}")
        
        # Business model risks
        if parsed_idea['business_model'] in ['advertising', 'freemium']:
            risks.append("Business model requires significant scale for profitability")
        
        # Execution risks
        if not parsed_idea.get('key_features'):
            risks.append("Lack of specific features may indicate unclear execution plan")
        
        return risks[:5]
    
    def _identify_success_factors(self, parsed_idea: Dict, market_data: Dict) -> List[str]:
        """Identify key success factors"""
        factors = []
        
        # Market factors
        growth_rate_str = market_data.get('growth_rate', '')
        import re
        numbers = re.findall(r'[\d.]+', growth_rate_str)
        if numbers and float(numbers[0]) > 12:
            factors.append(f"Strong market growth rate ({market_data.get('growth_rate')})")
        
        # Trend alignment
        trends = market_data.get('trends', [])
        if trends:
            factors.append(f"Aligned with key trend: {trends[0]}")
        
        # Customer needs
        needs = market_data.get('customer_needs', [])
        if needs:
            factors.append(f"Addresses critical need: {needs[0]}")
        
        # Business model strength
        if parsed_idea['business_model'] in ['subscription', 'saas', 'marketplace']:
            factors.append(f"Strong {parsed_idea['business_model']} business model with recurring revenue")
        
        # Target customer
        if parsed_idea.get('target_customer') != 'General Consumers':
            factors.append(f"Focused on specific target: {parsed_idea['target_customer']}")
        
        return factors[:5]
    
    def get_recommendation(self, score: float) -> Dict:
        """Get actionable recommendation based on score"""
        if score >= 75:
            return {
                'verdict': 'PURSUE',
                'color': 'green',
                'message': 'Strong opportunity - Recommend proceeding with MVP development',
                'next_steps': [
                    'Validate with potential customers',
                    'Build minimum viable product (MVP)',
                    'Develop go-to-market strategy',
                    'Secure initial funding or bootstrap',
                ]
            }
        elif score >= 65:
            return {
                'verdict': 'REFINE',
                'color': 'orange',
                'message': 'Promising opportunity - Recommend refining before full commitment',
                'next_steps': [
                    'Conduct deeper customer research',
                    'Strengthen differentiation strategy',
                    'Validate unit economics',
                    'Consider pivoting positioning',
                ]
            }
        else:
            return {
                'verdict': 'RECONSIDER',
                'color': 'red',
                'message': 'Challenging opportunity - Recommend significant changes or pivot',
                'next_steps': [
                    'Identify critical issues to address',
                    'Explore alternative approaches',
                    'Research less competitive niches',
                    'Consider different business models',
                ]
            }
