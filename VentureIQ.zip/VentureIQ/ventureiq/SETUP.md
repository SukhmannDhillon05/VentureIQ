# VentureIQ Setup Guide

## Quick Start

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Installation Steps

1. **Navigate to the VentureIQ directory**
```bash
cd ventureiq
```

2. **Install Python dependencies**
```bash
pip install -r requirements.txt
```

3. **Run the Streamlit application**
```bash
streamlit run app.py
```

4. **Access the application**
- Open your browser to: http://localhost:8501
- The Next.js homepage at http://localhost:3000 has a "Launch VentureIQ" button that links to the app

## Testing the Application

### Example Business Ideas to Test

**HealthTech Example:**
```
A mobile app for busy professionals that uses AI to create personalized meal plans and automatically orders groceries for delivery. We solve the problem of healthy eating being time-consuming. Target customers are working professionals aged 25-45 who value health but lack time. Subscription model at $29/month with features including AI meal planning, grocery auto-ordering, and nutrition tracking.
```

**FinTech Example:**
```
A digital banking platform for freelancers that provides instant invoicing, automated tax savings, and expense tracking. Problem: Freelancers struggle with financial management and tax preparation. Target: Independent contractors and gig workers. Business model: Monthly subscription at $15/month with premium features at $40/month.
```

**EdTech Example:**
```
An online platform connecting students with peer tutors for real-time homework help. We solve the affordability problem of traditional tutoring. Target: High school and college students. Marketplace model with 20% commission on tutoring sessions. Features include video chat, whiteboard, and session recording.
```

## Features to Explore

1. **Idea Parser** - Enter your idea and watch it extract key components
2. **Competitor Intelligence** - View 7+ competitors with detailed analysis
3. **Market Research** - Explore market size, trends, and opportunities
4. **Financial Projections** - Interactive 3-year revenue charts
5. **Success Score** - Get a 0-100% success probability with reasoning
6. **PDF Report** - Download comprehensive validation report

## Troubleshooting

### Port Already in Use
If port 8501 is already in use:
```bash
streamlit run app.py --server.port 8502
```

### Missing Dependencies
If you encounter import errors:
```bash
pip install --upgrade -r requirements.txt
```

### PDF Generation Issues
If PDF generation fails, ensure you have the required system fonts:
- **macOS**: Fonts should work by default
- **Linux**: `sudo apt-get install fonts-liberation`
- **Windows**: System fonts should work by default

## Application Structure

```
ventureiq/
├── app.py                      # Main Streamlit application
├── idea_parser.py             # NLP-based idea extraction
├── competitor_intelligence.py # Competitor finding & analysis
├── market_research.py         # Market size & trends
├── success_predictor.py       # Success scoring algorithm
├── financial_model.py         # Financial projections engine
├── report_generator.py        # PDF report creation
├── requirements.txt           # Python dependencies
├── README.md                  # Project documentation
└── SETUP.md                   # This file
```

## Configuration Options

### Streamlit Configuration
Create `.streamlit/config.toml` to customize:

```toml
[theme]
primaryColor = "#667eea"
backgroundColor = "#ffffff"
secondaryBackgroundColor = "#f0f2f6"
textColor = "#262730"
font = "sans serif"

[server]
port = 8501
enableCORS = false
```

### Custom Mock Data
Edit `competitor_intelligence.py` to add your own mock competitor databases for testing.

## Performance Tips

1. **Competitor Analysis**: Start with 5-7 competitors for faster analysis
2. **Industry Selection**: Use the industry hint dropdown for better results
3. **PDF Generation**: May take 10-15 seconds for complex reports

## Next Steps

1. Test with various business ideas from different industries
2. Explore all tabs in the results dashboard
3. Generate and review PDF reports
4. Customize mock competitor data for your specific use case
5. Integrate real web scraping APIs for production use

## Production Deployment

For production deployment, consider:
- Using real competitor search APIs (SerpAPI, Google Custom Search)
- Implementing user authentication
- Adding database storage for analysis history
- Setting up proper API rate limiting
- Using cloud storage for generated reports

## Support

For issues or questions:
- Check the README.md for feature documentation
- Review the code comments for implementation details
- Modify mock databases in competitor_intelligence.py for testing
