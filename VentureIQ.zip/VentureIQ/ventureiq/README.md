# VentureIQ - AI Business Idea Validator

## Overview
VentureIQ is a comprehensive business idea validation platform that analyzes ideas and generates detailed validation reports.

## Features

### 🎯 Idea Parser
- Extracts industry, target customer, problem, solution, and business model from natural language
- Accurate industry classification (fashion-tech, healthtech, fintech, etc.)

### 🔍 Competitor Intelligence (PRIMARY FEATURE)
- Finds 5-10 competitors via web search
- Scrapes competitor websites for pricing, features, positioning
- Creates comparison matrix and gap analysis
- Identifies market opportunities
- Uses fallback mock competitor database

### 📊 Market Research
- Niche-specific market size (not generic data)
- Industry-specific trends and pain points
- Customer needs validation

### 💰 Financial Modeling
- Clear assumptions (pricing, users, conversion rates)
- 3-year projections with monthly breakdown
- Interactive sliders for scenario planning
- Charts for revenue growth

### 🎯 Success Predictor
- Score 0-100% based on market size, competition, uniqueness, timing
- Component scores with reasoning
- Adjusted for data quality/confidence

### 📄 Report Generator
- Professional 15-20 page PDF with charts
- Sections: Executive Summary, Market Analysis, Competitors (most detailed), Financials, Recommendations

### 💻 Interactive Streamlit UI
- Engaging hero section with animations
- Multi-step input form
- Immersive loading with real-time progress updates
- Tabbed results dashboard with interactive charts
- Competitor comparison interface
- Financial projection sliders

## Installation

```bash
cd ventureiq
pip install -r requirements.txt
```

## Usage

```bash
streamlit run app.py
```

Then open your browser to http://localhost:8501

## How to Use

1. **Enter Your Idea**: Describe your business concept, target customers, problem solved, and business model
2. **Select Options**: Choose industry category (optional) and number of competitors to analyze
3. **Analyze**: Click "Analyze My Idea" and watch the real-time progress
4. **Review Results**: Explore the tabbed dashboard with:
   - Overview with success score
   - Detailed competitor analysis
   - Market research insights
   - Financial projections
   - Downloadable PDF report

## Tech Stack

- **Python 3.8+**
- **Streamlit** - Interactive web interface
- **BeautifulSoup4** - Web scraping
- **Requests** - HTTP requests
- **Pandas** - Data manipulation
- **Plotly** - Interactive charts
- **ReportLab** - PDF generation

## Example Ideas to Test

```
A mobile app for busy professionals that uses AI to create personalized meal plans and automatically orders groceries for delivery. We solve the problem of healthy eating being time-consuming. Target customers are working professionals aged 25-45 who value health but lack time. Subscription model at $29/month with features including AI meal planning, grocery auto-ordering, and nutrition tracking.
```

```
An online platform connecting freelance designers with small businesses for affordable branding services. Problem: Small businesses can't afford expensive branding agencies. Solution: Marketplace model with 15% commission. Target: Small businesses with <50 employees. Features include designer portfolio, project management, and secure payments.
```

## Features

- ✅ Real competitor data with mock fallback
- ✅ Specific industry classification
- ✅ Niche-specific market research
- ✅ Clear financial assumptions
- ✅ Realistic success scores (65-80% typically)
- ✅ Comprehensive error handling
- ✅ Modern, engaging UI with animations

## License

MIT License
