"""
Financial Modeling Module
Creates 3-year financial projections with assumptions
"""

from typing import Dict, List
import pandas as pd
import random

class FinancialModeler:
    def __init__(self):
        self.default_assumptions = {
            'subscription': {
                'avg_price': 49,
                'year1_users': 500,
                'monthly_growth_rate': 15,
                'churn_rate': 5,
                'conversion_rate': 3,
            },
            'marketplace': {
                'avg_transaction': 150,
                'year1_transactions': 1000,
                'monthly_growth_rate': 20,
                'commission_rate': 15,
                'repeat_rate': 40,
            },
            'ecommerce': {
                'avg_order_value': 75,
                'year1_orders': 800,
                'monthly_growth_rate': 12,
                'gross_margin': 40,
                'return_rate': 15,
            },
            'saas': {
                'avg_price': 99,
                'year1_customers': 300,
                'monthly_growth_rate': 18,
                'churn_rate': 3,
                'expansion_revenue': 20,
            },
        }
    
    def create_model(self, business_model: str, industry: str, 
                    custom_assumptions: Dict = None) -> Dict:
        """Create comprehensive financial model"""
        
        # Get base assumptions
        assumptions = self._get_assumptions(business_model, custom_assumptions)
        
        # Generate 3-year projections
        projections = self._generate_projections(assumptions, business_model)
        
        # Calculate key metrics
        metrics = self._calculate_metrics(projections, assumptions)
        
        return {
            'assumptions': assumptions,
            'projections': projections,
            'metrics': metrics,
            'charts_data': self._prepare_chart_data(projections),
        }
    
    def _get_assumptions(self, business_model: str, custom: Dict = None) -> Dict:
        """Get assumptions for the business model"""
        base = self.default_assumptions.get(
            business_model, 
            self.default_assumptions['subscription']
        ).copy()
        
        if custom:
            base.update(custom)
        
        # Add common assumptions
        base.update({
            'cac': base.get('cac', random.randint(50, 200)),  # Customer acquisition cost
            'operating_costs_fixed': base.get('operating_costs_fixed', 5000),  # Monthly fixed costs
            'operating_costs_variable_pct': base.get('operating_costs_variable_pct', 25),  # % of revenue
        })
        
        return base
    
    def _generate_projections(self, assumptions: Dict, model: str) -> pd.DataFrame:
        """Generate month-by-month projections for 3 years"""
        months = 36
        data = []
        
        if model in ['subscription', 'saas']:
            data = self._project_subscription(assumptions, months)
        elif model == 'marketplace':
            data = self._project_marketplace(assumptions, months)
        elif model == 'ecommerce':
            data = self._project_ecommerce(assumptions, months)
        else:
            data = self._project_subscription(assumptions, months)
        
        df = pd.DataFrame(data)
        return df
    
    def _project_subscription(self, assumptions: Dict, months: int) -> List[Dict]:
        """Project subscription business model"""
        data = []
        
        users = assumptions['year1_users'] / 12  # Start with monthly users
        price = assumptions['avg_price']
        growth_rate = assumptions['monthly_growth_rate'] / 100
        churn_rate = assumptions['churn_rate'] / 100
        
        for month in range(1, months + 1):
            # Calculate users
            new_users = users * growth_rate
            churned_users = users * churn_rate
            users = users + new_users - churned_users
            
            # Calculate revenue
            mrr = users * price
            
            # Calculate costs
            fixed_costs = assumptions['operating_costs_fixed']
            variable_costs = mrr * (assumptions['operating_costs_variable_pct'] / 100)
            cac_spend = new_users * assumptions['cac']
            total_costs = fixed_costs + variable_costs + cac_spend
            
            # Calculate profit
            gross_profit = mrr - variable_costs
            net_profit = mrr - total_costs
            
            data.append({
                'month': month,
                'year': (month - 1) // 12 + 1,
                'users': int(users),
                'new_users': int(new_users),
                'churned_users': int(churned_users),
                'revenue': round(mrr, 2),
                'gross_profit': round(gross_profit, 2),
                'net_profit': round(net_profit, 2),
                'fixed_costs': fixed_costs,
                'variable_costs': round(variable_costs, 2),
                'cac_spend': round(cac_spend, 2),
                'total_costs': round(total_costs, 2),
            })
        
        return data
    
    def _project_marketplace(self, assumptions: Dict, months: int) -> List[Dict]:
        """Project marketplace business model"""
        data = []
        
        transactions = assumptions['year1_transactions'] / 12
        avg_transaction = assumptions['avg_transaction']
        growth_rate = assumptions['monthly_growth_rate'] / 100
        commission = assumptions['commission_rate'] / 100
        
        for month in range(1, months + 1):
            # Calculate transactions
            new_transactions = transactions * growth_rate
            transactions = transactions + new_transactions
            
            # Calculate revenue
            gmv = transactions * avg_transaction  # Gross Merchandise Value
            revenue = gmv * commission
            
            # Calculate costs
            fixed_costs = assumptions['operating_costs_fixed']
            variable_costs = revenue * (assumptions['operating_costs_variable_pct'] / 100)
            marketing_spend = new_transactions * (assumptions['cac'] / 2)  # Lower CAC for marketplaces
            total_costs = fixed_costs + variable_costs + marketing_spend
            
            # Calculate profit
            gross_profit = revenue - variable_costs
            net_profit = revenue - total_costs
            
            data.append({
                'month': month,
                'year': (month - 1) // 12 + 1,
                'transactions': int(transactions),
                'gmv': round(gmv, 2),
                'revenue': round(revenue, 2),
                'gross_profit': round(gross_profit, 2),
                'net_profit': round(net_profit, 2),
                'fixed_costs': fixed_costs,
                'variable_costs': round(variable_costs, 2),
                'marketing_spend': round(marketing_spend, 2),
                'total_costs': round(total_costs, 2),
            })
        
        return data
    
    def _project_ecommerce(self, assumptions: Dict, months: int) -> List[Dict]:
        """Project ecommerce business model"""
        data = []
        
        orders = assumptions['year1_orders'] / 12
        aov = assumptions['avg_order_value']
        growth_rate = assumptions['monthly_growth_rate'] / 100
        margin = assumptions['gross_margin'] / 100
        
        for month in range(1, months + 1):
            # Calculate orders
            new_orders = orders * growth_rate
            orders = orders + new_orders
            
            # Calculate revenue
            gross_revenue = orders * aov
            revenue = gross_revenue * margin  # After COGS
            
            # Calculate costs
            fixed_costs = assumptions['operating_costs_fixed']
            variable_costs = revenue * (assumptions['operating_costs_variable_pct'] / 100)
            marketing_spend = new_orders * assumptions['cac']
            total_costs = fixed_costs + variable_costs + marketing_spend
            
            # Calculate profit
            gross_profit = revenue - variable_costs
            net_profit = revenue - total_costs
            
            data.append({
                'month': month,
                'year': (month - 1) // 12 + 1,
                'orders': int(orders),
                'revenue': round(revenue, 2),
                'gross_profit': round(gross_profit, 2),
                'net_profit': round(net_profit, 2),
                'fixed_costs': fixed_costs,
                'variable_costs': round(variable_costs, 2),
                'marketing_spend': round(marketing_spend, 2),
                'total_costs': round(total_costs, 2),
            })
        
        return data
    
    def _calculate_metrics(self, df: pd.DataFrame, assumptions: Dict) -> Dict:
        """Calculate key financial metrics"""
        
        # Yearly summaries
        yearly = df.groupby('year').agg({
            'revenue': 'sum',
            'gross_profit': 'sum',
            'net_profit': 'sum',
            'total_costs': 'sum',
        }).round(2)
        
        # Key metrics
        total_revenue = df['revenue'].sum()
        total_costs = df['total_costs'].sum()
        total_profit = df['net_profit'].sum()
        
        year1_revenue = yearly.loc[1, 'revenue'] if 1 in yearly.index else 0
        year2_revenue = yearly.loc[2, 'revenue'] if 2 in yearly.index else 0
        year3_revenue = yearly.loc[3, 'revenue'] if 3 in yearly.index else 0
        
        # Calculate growth rates
        yoy_growth_y2 = ((year2_revenue - year1_revenue) / year1_revenue * 100) if year1_revenue > 0 else 0
        yoy_growth_y3 = ((year3_revenue - year2_revenue) / year2_revenue * 100) if year2_revenue > 0 else 0
        
        # Profitability metrics
        gross_margin = (df['gross_profit'].sum() / total_revenue * 100) if total_revenue > 0 else 0
        net_margin = (total_profit / total_revenue * 100) if total_revenue > 0 else 0
        
        # Find break-even month
        breakeven_month = None
        cumulative_profit = 0
        for _, row in df.iterrows():
            cumulative_profit += row['net_profit']
            if cumulative_profit > 0 and breakeven_month is None:
                breakeven_month = row['month']
                break
        
        return {
            'yearly_summary': yearly.to_dict(),
            'total_revenue_3y': round(total_revenue, 2),
            'total_profit_3y': round(total_profit, 2),
            'year1_revenue': round(year1_revenue, 2),
            'year2_revenue': round(year2_revenue, 2),
            'year3_revenue': round(year3_revenue, 2),
            'yoy_growth_y2': round(yoy_growth_y2, 1),
            'yoy_growth_y3': round(yoy_growth_y3, 1),
            'gross_margin_pct': round(gross_margin, 1),
            'net_margin_pct': round(net_margin, 1),
            'breakeven_month': breakeven_month if breakeven_month else 'Not reached',
            'avg_monthly_revenue': round(total_revenue / 36, 2),
        }
    
    def _prepare_chart_data(self, df: pd.DataFrame) -> Dict:
        """Prepare data for charts"""
        return {
            'monthly_revenue': df[['month', 'revenue']].to_dict('records'),
            'monthly_profit': df[['month', 'net_profit']].to_dict('records'),
            'yearly_comparison': df.groupby('year')['revenue'].sum().to_dict(),
            'cost_breakdown': {
                'fixed_costs': df['fixed_costs'].sum(),
                'variable_costs': df['variable_costs'].sum(),
                'marketing': df.get('cac_spend', df.get('marketing_spend', pd.Series([0]))).sum(),
            }
        }
    
    def update_assumptions(self, current_assumptions: Dict, 
                          parameter: str, value: float) -> Dict:
        """Update a single assumption parameter"""
        updated = current_assumptions.copy()
        updated[parameter] = value
        return updated
