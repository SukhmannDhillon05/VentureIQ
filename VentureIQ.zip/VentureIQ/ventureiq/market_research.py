"""
Market Research Module
Analyzes market size, trends, and customer needs
"""

from typing import Dict, List
import random

class MarketResearcher:
    def __init__(self):
        self.market_data = self._initialize_market_data()
    
    def research_market(self, industry: str, target_customer: str) -> Dict:
        """Conduct market research for specific industry and customer segment"""
        
        market_info = self.market_data.get(industry, self.market_data['general-tech'])
        
        # Calculate niche-specific market size
        niche_size = self._calculate_niche_size(market_info, target_customer)
        
        return {
            'total_market_size': market_info['total_market_size'],
            'niche_market_size': niche_size,
            'growth_rate': market_info['growth_rate'],
            'trends': market_info['trends'],
            'pain_points': market_info['pain_points'],
            'customer_needs': self._identify_customer_needs(industry, target_customer),
            'market_maturity': market_info['maturity'],
            'entry_barriers': market_info['barriers'],
        }
    
    def _calculate_niche_size(self, market_info: Dict, target_customer: str) -> str:
        """Calculate niche-specific market size"""
        total = market_info['total_market_size']
        
        # Parse numeric value
        import re
        numbers = re.findall(r'[\d.]+', total)
        if numbers:
            base_value = float(numbers[0])
            
            # Niche is typically 10-30% of total market
            niche_percentage = random.uniform(0.10, 0.30)
            niche_value = base_value * niche_percentage
            
            if 'B' in total:
                return f"${niche_value:.1f}B ({int(niche_percentage*100)}% of total market)"
            elif 'M' in total:
                return f"${niche_value:.0f}M ({int(niche_percentage*100)}% of total market)"
        
        return "Data not available"
    
    def _identify_customer_needs(self, industry: str, target_customer: str) -> List[str]:
        """Identify specific customer needs"""
        needs_map = {
            'healthtech': [
                'Easy tracking of health metrics',
                'Personalized recommendations',
                'Integration with wearables',
                'Privacy and data security',
                'Affordable pricing',
            ],
            'fintech': [
                'Transparent and low fees',
                'Fast transaction processing',
                'Strong security measures',
                'User-friendly interface',
                'Regulatory compliance',
            ],
            'edtech': [
                'Flexible learning schedules',
                'Interactive content',
                'Progress tracking',
                'Certification/credentials',
                'Affordable access to quality education',
            ],
            'fashion-tech': [
                'Sustainable fashion options',
                'Personalized style recommendations',
                'Easy returns and exchanges',
                'Size accuracy',
                'Affordable luxury',
            ],
            'saas': [
                'Easy implementation',
                'Scalability',
                'Integration capabilities',
                'Reliable uptime',
                'Responsive customer support',
            ],
        }
        
        return needs_map.get(industry, [
            'Ease of use',
            'Affordability',
            'Reliability',
            'Customer support',
            'Value for money',
        ])
    
    def _initialize_market_data(self) -> Dict:
        """Initialize market data by industry"""
        return {
            'healthtech': {
                'total_market_size': '$295B',
                'growth_rate': '15.1% CAGR',
                'maturity': 'Growth stage',
                'trends': [
                    'AI-powered personalization in wellness',
                    'Mental health awareness increasing',
                    'Preventive care over reactive treatment',
                    'Integration with wearables and IoT',
                    'Telemedicine adoption accelerating',
                ],
                'pain_points': [
                    'High customer acquisition costs',
                    'User retention challenges',
                    'Privacy regulations (HIPAA compliance)',
                    'Medical accuracy requirements',
                    'Insurance reimbursement complexity',
                ],
                'barriers': [
                    'Regulatory compliance (FDA, HIPAA)',
                    'Medical credibility requirements',
                    'High customer acquisition costs',
                ],
            },
            'fintech': {
                'total_market_size': '$312B',
                'growth_rate': '20.3% CAGR',
                'maturity': 'Growth stage',
                'trends': [
                    'Embedded finance in non-financial apps',
                    'Cryptocurrency mainstream adoption',
                    'Buy now, pay later (BNPL) growth',
                    'AI for fraud detection',
                    'Open banking APIs',
                ],
                'pain_points': [
                    'Customer trust and security concerns',
                    'Regulatory compliance burden',
                    'High customer support demands',
                    'Fraud and chargebacks',
                    'Banking partnership challenges',
                ],
                'barriers': [
                    'Heavy regulation (PCI-DSS, SOC 2)',
                    'Banking partnerships required',
                    'High security requirements',
                    'License requirements',
                ],
            },
            'edtech': {
                'total_market_size': '$227B',
                'growth_rate': '16.5% CAGR',
                'maturity': 'Growth stage',
                'trends': [
                    'Microlearning and bite-sized content',
                    'Gamification for engagement',
                    'AI tutors and adaptive learning',
                    'Skills-based learning over degrees',
                    'Corporate upskilling demand',
                ],
                'pain_points': [
                    'Low course completion rates',
                    'Content creation costs',
                    'Proving ROI to students',
                    'Competition with free content',
                    'Teacher/creator acquisition',
                ],
                'barriers': [
                    'Content creation costs',
                    'Building credibility',
                    'Low willingness to pay',
                ],
            },
            'fashion-tech': {
                'total_market_size': '$185B',
                'growth_rate': '12.8% CAGR',
                'maturity': 'Growth stage',
                'trends': [
                    'Sustainability and circular fashion',
                    'Virtual try-on technology (AR)',
                    'Direct-to-consumer brands',
                    'Resale and rental models',
                    'Personalization through AI',
                ],
                'pain_points': [
                    'High return rates (30-40%)',
                    'Inventory management complexity',
                    'Size and fit accuracy',
                    'Fast fashion competition',
                    'Logistics and shipping costs',
                ],
                'barriers': [
                    'Inventory and logistics complexity',
                    'High return rates',
                    'Brand building costs',
                ],
            },
            'foodtech': {
                'total_market_size': '$220B',
                'growth_rate': '13.2% CAGR',
                'maturity': 'Growth stage',
                'trends': [
                    'Ghost kitchens and cloud restaurants',
                    'Plant-based alternatives',
                    'Hyper-local delivery',
                    'Food waste reduction tech',
                    'AI for menu optimization',
                ],
                'pain_points': [
                    'Thin margins (10-15%)',
                    'Delivery logistics complexity',
                    'Restaurant partnership challenges',
                    'Quality control during delivery',
                    'Peak demand fluctuations',
                ],
                'barriers': [
                    'Logistics complexity',
                    'Low margins',
                    'Food safety regulations',
                ],
            },
            'saas': {
                'total_market_size': '$195B',
                'growth_rate': '18.7% CAGR',
                'maturity': 'Mature',
                'trends': [
                    'AI-powered features becoming table stakes',
                    'Vertical SaaS dominating niches',
                    'Usage-based pricing models',
                    'No-code/low-code tools',
                    'API-first architectures',
                ],
                'pain_points': [
                    'High churn rates (5-7% monthly)',
                    'Long sales cycles for enterprise',
                    'Customer support scalability',
                    'Feature bloat vs. simplicity',
                    'Competition from incumbents',
                ],
                'barriers': [
                    'High customer acquisition costs',
                    'Long sales cycles',
                    'Need for continuous innovation',
                ],
            },
            'ecommerce': {
                'total_market_size': '$5.7T',
                'growth_rate': '14.7% CAGR',
                'maturity': 'Mature',
                'trends': [
                    'Social commerce integration',
                    'Live shopping experiences',
                    'Same-day delivery expectations',
                    'Sustainability focus',
                    'Personalization through AI',
                ],
                'pain_points': [
                    'Customer acquisition costs rising',
                    'Amazon competition',
                    'Logistics complexity',
                    'Payment fraud',
                    'Customer retention challenges',
                ],
                'barriers': [
                    'High competition',
                    'Logistics requirements',
                    'Payment processing setup',
                ],
            },
            'general-tech': {
                'total_market_size': '$150B',
                'growth_rate': '12% CAGR',
                'maturity': 'Varies',
                'trends': [
                    'AI/ML integration',
                    'Cloud-native solutions',
                    'Mobile-first approach',
                    'API-driven architectures',
                    'Subscription models',
                ],
                'pain_points': [
                    'User acquisition costs',
                    'Retention challenges',
                    'Technical complexity',
                    'Competition',
                    'Scaling issues',
                ],
                'barriers': [
                    'Technology development costs',
                    'Market competition',
                    'User adoption',
                ],
            },
        }
    
    def get_market_insights(self, industry: str) -> Dict:
        """Get high-level market insights"""
        market_info = self.market_data.get(industry, self.market_data['general-tech'])
        
        return {
            'is_growing': float(market_info['growth_rate'].split('%')[0]) > 10,
            'market_size_assessment': self._assess_market_size(market_info['total_market_size']),
            'competition_level': self._assess_competition(market_info['maturity']),
            'opportunity_score': self._calculate_opportunity_score(market_info),
        }
    
    def _assess_market_size(self, size_str: str) -> str:
        """Assess if market size is attractive"""
        import re
        numbers = re.findall(r'[\d.]+', size_str)
        if numbers:
            value = float(numbers[0])
            if 'T' in size_str or (value > 100 and 'B' in size_str):
                return 'Very Large - Significant opportunity'
            elif value > 50 and 'B' in size_str:
                return 'Large - Good opportunity'
            elif 'B' in size_str:
                return 'Moderate - Viable market'
            else:
                return 'Small - Niche opportunity'
        return 'Unknown'
    
    def _assess_competition(self, maturity: str) -> str:
        """Assess competition level"""
        if 'mature' in maturity.lower():
            return 'High - Established players dominate'
        elif 'growth' in maturity.lower():
            return 'Moderate - Growing market with opportunities'
        else:
            return 'Low - Early stage market'
    
    def _calculate_opportunity_score(self, market_info: Dict) -> float:
        """Calculate market opportunity score (0-100)"""
        score = 50  # Base score
        
        # Adjust based on growth rate
        growth_rate = float(market_info['growth_rate'].split('%')[0])
        if growth_rate > 15:
            score += 20
        elif growth_rate > 10:
            score += 10
        elif growth_rate < 5:
            score -= 10
        
        # Adjust based on maturity
        if market_info['maturity'] == 'Growth stage':
            score += 15
        elif market_info['maturity'] == 'Mature':
            score -= 10
        
        # Adjust based on barriers
        barrier_count = len(market_info['barriers'])
        score -= barrier_count * 5
        
        return min(max(score, 0), 100)
