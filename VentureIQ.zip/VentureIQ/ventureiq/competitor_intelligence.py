"""
Competitor Intelligence Module
Finds and analyzes competitors through web search and scraping
"""

import requests
from bs4 import BeautifulSoup
from typing import List, Dict, Optional
import time
import random

class CompetitorIntelligence:
    def __init__(self):
        self.mock_database = self._initialize_mock_db()
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    
    def find_competitors(self, industry: str, solution: str, num_competitors: int = 7) -> List[Dict]:
        """Find competitors using web search with mock fallback"""
        try:
            # Try to search for real competitors
            competitors = self._search_competitors(industry, solution)
            
            if len(competitors) < 3:
                # Fallback to mock data if insufficient results
                print("Using mock competitor database...")
                competitors = self._get_mock_competitors(industry, num_competitors)
            
            # Enrich with scraped data
            enriched = []
            for comp in competitors[:num_competitors]:
                enriched_comp = self._enrich_competitor_data(comp)
                enriched.append(enriched_comp)
            
            return enriched
        except Exception as e:
            print(f"Error finding competitors: {e}")
            return self._get_mock_competitors(industry, num_competitors)
    
    def _search_competitors(self, industry: str, solution: str) -> List[Dict]:
        """Search for competitors (simplified - real implementation would use search APIs)"""
        # This is a simplified version - real implementation would use:
        # - Google Custom Search API
        # - Bing Search API
        # - SerpAPI
        
        competitors = []
        
        # For demo, return empty to trigger mock fallback
        # In production, implement actual search logic here
        
        return competitors
    
    def _enrich_competitor_data(self, competitor: Dict) -> Dict:
        """Scrape competitor website for additional data"""
        try:
            if 'website' in competitor and competitor['website']:
                scraped_data = self._scrape_website(competitor['website'])
                competitor.update(scraped_data)
        except Exception as e:
            print(f"Error scraping {competitor.get('name', 'unknown')}: {e}")
        
        return competitor
    
    def _scrape_website(self, url: str) -> Dict:
        """Scrape website for pricing, features, etc."""
        try:
            response = requests.get(url, headers=self.headers, timeout=5)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract pricing (look for common patterns)
            pricing = self._extract_pricing(soup)
            
            # Extract features
            features = self._extract_features(soup)
            
            return {
                'scraped_pricing': pricing,
                'scraped_features': features,
            }
        except Exception as e:
            return {}
    
    def _extract_pricing(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract pricing from webpage"""
        price_patterns = ['$', 'price', 'pricing', 'cost']
        
        for pattern in price_patterns:
            elements = soup.find_all(text=lambda text: pattern in text.lower() if text else False)
            for elem in elements[:3]:
                if '$' in elem:
                    return elem.strip()[:100]
        
        return None
    
    def _extract_features(self, soup: BeautifulSoup) -> List[str]:
        """Extract features from webpage"""
        features = []
        
        # Look for lists
        lists = soup.find_all(['ul', 'ol'])
        for lst in lists[:3]:
            items = lst.find_all('li')
            features.extend([item.get_text().strip() for item in items[:5]])
        
        return features[:10]
    
    def _get_mock_competitors(self, industry: str, num: int = 7) -> List[Dict]:
        """Get competitors from mock database"""
        industry_comps = self.mock_database.get(industry, self.mock_database['general-tech'])
        return industry_comps[:num]
    
    def _initialize_mock_db(self) -> Dict:
        """Initialize mock competitor database"""
        return {
            'healthtech': [
                {
                    'name': 'HealthifyMe',
                    'website': 'https://healthifyme.com',
                    'positioning': 'AI-powered health & fitness coach',
                    'pricing': 'Freemium: $0-15/month',
                    'strengths': ['Large user base', 'AI nutrition tracking', 'Indian market leader'],
                    'weaknesses': ['Limited international presence', 'Basic workout plans'],
                    'market_share': '12%',
                    'funding': '$100M',
                    'year_founded': 2012,
                },
                {
                    'name': 'MyFitnessPal',
                    'website': 'https://myfitnesspal.com',
                    'positioning': 'Comprehensive calorie counter & diet tracker',
                    'pricing': 'Freemium: $0-80/year',
                    'strengths': ['Massive food database', 'Strong brand', 'Global reach'],
                    'weaknesses': ['Outdated UI', 'Heavy ads on free tier'],
                    'market_share': '25%',
                    'funding': 'Acquired by Under Armour',
                    'year_founded': 2005,
                },
                {
                    'name': 'Noom',
                    'website': 'https://noom.com',
                    'positioning': 'Psychology-based weight loss program',
                    'pricing': '$60-99/month',
                    'strengths': ['Behavioral psychology focus', 'Personal coaching', 'High engagement'],
                    'weaknesses': ['Expensive', 'Requires commitment'],
                    'market_share': '8%',
                    'funding': '$540M',
                    'year_founded': 2008,
                },
                {
                    'name': 'Fitbit Premium',
                    'website': 'https://fitbit.com',
                    'positioning': 'Wearable-integrated health insights',
                    'pricing': '$10/month',
                    'strengths': ['Hardware integration', 'Comprehensive tracking', 'Google backing'],
                    'weaknesses': ['Requires Fitbit device', 'Premium features locked'],
                    'market_share': '15%',
                    'funding': 'Acquired by Google',
                    'year_founded': 2007,
                },
                {
                    'name': 'Headspace',
                    'website': 'https://headspace.com',
                    'positioning': 'Meditation & mental wellness',
                    'pricing': '$13/month',
                    'strengths': ['Mental health focus', 'Quality content', 'Enterprise partnerships'],
                    'weaknesses': ['Limited to meditation', 'Niche audience'],
                    'market_share': '6%',
                    'funding': '$216M',
                    'year_founded': 2010,
                },
                {
                    'name': 'Calm',
                    'website': 'https://calm.com',
                    'positioning': 'Sleep & meditation app',
                    'pricing': '$15/month',
                    'strengths': ['Sleep focus', 'Celebrity content', 'Beautiful design'],
                    'weaknesses': ['Expensive', 'Limited free content'],
                    'market_share': '10%',
                    'funding': '$218M',
                    'year_founded': 2012,
                },
                {
                    'name': 'Peloton Digital',
                    'website': 'https://onepeloton.com',
                    'positioning': 'Live & on-demand fitness classes',
                    'pricing': '$13-44/month',
                    'strengths': ['Live classes', 'Community', 'Quality instructors'],
                    'weaknesses': ['Hardware dependency', 'Recent struggles'],
                    'market_share': '5%',
                    'funding': 'Public (NASDAQ: PTON)',
                    'year_founded': 2012,
                },
            ],
            'fintech': [
                {
                    'name': 'Robinhood',
                    'website': 'https://robinhood.com',
                    'positioning': 'Commission-free trading for all',
                    'pricing': 'Free + $5/month premium',
                    'strengths': ['Zero commissions', 'Simple UX', 'Crypto support'],
                    'weaknesses': ['Gamification concerns', 'Limited research tools'],
                    'market_share': '18%',
                    'funding': 'Public (NASDAQ: HOOD)',
                    'year_founded': 2013,
                },
                {
                    'name': 'Stripe',
                    'website': 'https://stripe.com',
                    'positioning': 'Payment infrastructure for the internet',
                    'pricing': '2.9% + 30¢ per transaction',
                    'strengths': ['Developer-friendly', 'Global reach', 'Comprehensive APIs'],
                    'weaknesses': ['Complex pricing', 'Strict compliance'],
                    'market_share': '20%',
                    'funding': '$2.2B',
                    'year_founded': 2010,
                },
                {
                    'name': 'Chime',
                    'website': 'https://chime.com',
                    'positioning': 'Mobile banking with no fees',
                    'pricing': 'Free',
                    'strengths': ['No fees', 'Early paycheck', 'Savings features'],
                    'weaknesses': ['Limited physical presence', 'Customer service issues'],
                    'market_share': '12%',
                    'funding': '$2.3B',
                    'year_founded': 2013,
                },
                {
                    'name': 'PayPal',
                    'website': 'https://paypal.com',
                    'positioning': 'Digital wallet & payment platform',
                    'pricing': '2.99% per transaction',
                    'strengths': ['Brand recognition', 'Global network', 'Buyer protection'],
                    'weaknesses': ['High fees', 'Account freezes', 'Legacy platform'],
                    'market_share': '35%',
                    'funding': 'Public (NASDAQ: PYPL)',
                    'year_founded': 1998,
                },
                {
                    'name': 'Plaid',
                    'website': 'https://plaid.com',
                    'positioning': 'Financial data connectivity',
                    'pricing': 'Usage-based',
                    'strengths': ['Banking integrations', 'Data accuracy', 'Developer tools'],
                    'weaknesses': ['Privacy concerns', 'Bank blocking'],
                    'market_share': '8%',
                    'funding': '$734M',
                    'year_founded': 2013,
                },
                {
                    'name': 'Square (Block)',
                    'website': 'https://squareup.com',
                    'positioning': 'Commerce ecosystem for businesses',
                    'pricing': '2.6% + 10¢ per transaction',
                    'strengths': ['Hardware + software', 'SMB focus', 'Bitcoin integration'],
                    'weaknesses': ['Higher fees', 'Account holds'],
                    'market_share': '15%',
                    'funding': 'Public (NYSE: SQ)',
                    'year_founded': 2009,
                },
                {
                    'name': 'Revolut',
                    'website': 'https://revolut.com',
                    'positioning': 'Global digital banking',
                    'pricing': 'Freemium: $0-45/month',
                    'strengths': ['Multi-currency', 'Crypto trading', 'International transfers'],
                    'weaknesses': ['Regulatory challenges', 'Customer support'],
                    'market_share': '7%',
                    'funding': '$916M',
                    'year_founded': 2015,
                },
            ],
            'edtech': [
                {
                    'name': 'Coursera',
                    'website': 'https://coursera.org',
                    'positioning': 'Online courses from top universities',
                    'pricing': 'Freemium: $0-99/month',
                    'strengths': ['University partnerships', 'Certificates', 'Wide catalog'],
                    'weaknesses': ['Course completion rates', 'Limited interaction'],
                    'market_share': '22%',
                    'funding': 'Public (NYSE: COUR)',
                    'year_founded': 2012,
                },
                {
                    'name': 'Duolingo',
                    'website': 'https://duolingo.com',
                    'positioning': 'Gamified language learning',
                    'pricing': 'Freemium: $0-13/month',
                    'strengths': ['Gamification', 'Mobile-first', 'Free tier'],
                    'weaknesses': ['Limited speaking practice', 'Basic lessons'],
                    'market_share': '30%',
                    'funding': 'Public (NASDAQ: DUOL)',
                    'year_founded': 2011,
                },
                {
                    'name': 'Udemy',
                    'website': 'https://udemy.com',
                    'positioning': 'Marketplace for online courses',
                    'pricing': '$10-200 per course',
                    'strengths': ['Course variety', 'Affordable', 'Lifetime access'],
                    'weaknesses': ['Variable quality', 'No certificates', 'Discount culture'],
                    'market_share': '18%',
                    'funding': 'Private',
                    'year_founded': 2010,
                },
                {
                    'name': 'Khan Academy',
                    'website': 'https://khanacademy.org',
                    'positioning': 'Free education for anyone, anywhere',
                    'pricing': 'Free (nonprofit)',
                    'strengths': ['Completely free', 'K-12 focus', 'Quality content'],
                    'weaknesses': ['Limited advanced topics', 'No monetization'],
                    'market_share': '15%',
                    'funding': 'Nonprofit donations',
                    'year_founded': 2008,
                },
                {
                    'name': 'Skillshare',
                    'website': 'https://skillshare.com',
                    'positioning': 'Creative skills learning community',
                    'pricing': '$14-32/month',
                    'strengths': ['Creative focus', 'Project-based', 'Community'],
                    'weaknesses': ['Limited tech courses', 'Variable quality'],
                    'market_share': '10%',
                    'funding': '$66M',
                    'year_founded': 2010,
                },
                {
                    'name': 'MasterClass',
                    'website': 'https://masterclass.com',
                    'positioning': 'Learn from the best in the world',
                    'pricing': '$120-240/year',
                    'strengths': ['Celebrity instructors', 'Production quality', 'Inspiration'],
                    'weaknesses': ['Expensive', 'Surface-level', 'Limited practice'],
                    'market_share': '5%',
                    'funding': '$460M',
                    'year_founded': 2015,
                },
                {
                    'name': 'LinkedIn Learning',
                    'website': 'https://linkedin.com/learning',
                    'positioning': 'Professional skills development',
                    'pricing': '$40/month',
                    'strengths': ['Professional focus', 'LinkedIn integration', 'Certificates'],
                    'weaknesses': ['Dated content', 'Dry presentation'],
                    'market_share': '12%',
                    'funding': 'Microsoft owned',
                    'year_founded': 2015,
                },
            ],
            'fashion-tech': [
                {
                    'name': 'Stitch Fix',
                    'website': 'https://stitchfix.com',
                    'positioning': 'AI-powered personal styling service',
                    'pricing': '$20 styling fee per box',
                    'strengths': ['Data science', 'Personalization', 'Convenience'],
                    'weaknesses': ['Limited control', 'Return hassle'],
                    'market_share': '15%',
                    'funding': 'Public (NASDAQ: SFIX)',
                    'year_founded': 2011,
                },
                {
                    'name': 'Rent the Runway',
                    'website': 'https://renttherunway.com',
                    'positioning': 'Designer fashion rental subscription',
                    'pricing': '$89-235/month',
                    'strengths': ['Sustainability', 'Designer access', 'Occasion wear'],
                    'weaknesses': ['Size availability', 'Shipping delays'],
                    'market_share': '12%',
                    'funding': 'Public (NASDAQ: RENT)',
                    'year_founded': 2009,
                },
                {
                    'name': 'Poshmark',
                    'website': 'https://poshmark.com',
                    'positioning': 'Social commerce for fashion resale',
                    'pricing': 'Free (20% commission)',
                    'strengths': ['Social features', 'Easy selling', 'Brand variety'],
                    'weaknesses': ['Shipping costs', 'Lowball offers', 'Quality variance'],
                    'market_share': '20%',
                    'funding': 'Acquired by Naver',
                    'year_founded': 2011,
                },
                {
                    'name': 'Depop',
                    'website': 'https://depop.com',
                    'positioning': 'Gen Z fashion marketplace',
                    'pricing': 'Free (10% commission)',
                    'strengths': ['Young audience', 'Trendy items', 'Mobile-first'],
                    'weaknesses': ['Limited buyer protection', 'Fees'],
                    'market_share': '8%',
                    'funding': 'Acquired by Etsy',
                    'year_founded': 2011,
                },
                {
                    'name': 'ThredUp',
                    'website': 'https://thredup.com',
                    'positioning': 'Online consignment & thrift store',
                    'pricing': 'Free (commission varies)',
                    'strengths': ['Sustainability', 'Quality control', 'Easy selling'],
                    'weaknesses': ['Low seller payouts', 'Limited selection'],
                    'market_share': '10%',
                    'funding': 'Public (NASDAQ: TDUP)',
                    'year_founded': 2009,
                },
                {
                    'name': 'Vinted',
                    'website': 'https://vinted.com',
                    'positioning': 'European second-hand marketplace',
                    'pricing': 'Free (buyer protection fee)',
                    'strengths': ['No seller fees', 'European focus', 'Growing fast'],
                    'weaknesses': ['US expansion challenges', 'Scam concerns'],
                    'market_share': '18%',
                    'funding': '$562M',
                    'year_founded': 2008,
                },
                {
                    'name': 'Lyst',
                    'website': 'https://lyst.com',
                    'positioning': 'Fashion search engine',
                    'pricing': 'Free (affiliate model)',
                    'strengths': ['Aggregation', 'Price tracking', 'Brand variety'],
                    'weaknesses': ['Not direct sales', 'Redirects to retailers'],
                    'market_share': '7%',
                    'funding': '$160M',
                    'year_founded': 2010,
                },
            ],
            'general-tech': [
                {
                    'name': 'TechCo A',
                    'website': 'https://techco-a.com',
                    'positioning': 'Innovative tech solutions',
                    'pricing': '$10-50/month',
                    'strengths': ['User-friendly', 'Good support', 'Regular updates'],
                    'weaknesses': ['Limited features', 'Small team'],
                    'market_share': '10%',
                    'funding': '$5M',
                    'year_founded': 2018,
                },
                {
                    'name': 'TechCo B',
                    'website': 'https://techco-b.com',
                    'positioning': 'Enterprise-focused platform',
                    'pricing': '$100-500/month',
                    'strengths': ['Scalable', 'Security', 'Integrations'],
                    'weaknesses': ['Complex', 'Expensive'],
                    'market_share': '15%',
                    'funding': '$50M',
                    'year_founded': 2015,
                },
                {
                    'name': 'StartupZ',
                    'website': 'https://startupz.com',
                    'positioning': 'Modern approach to old problems',
                    'pricing': 'Freemium',
                    'strengths': ['Innovation', 'Fast growth', 'Modern UI'],
                    'weaknesses': ['Unproven', 'Limited track record'],
                    'market_share': '8%',
                    'funding': '$10M',
                    'year_founded': 2020,
                },
            ],
        }
    
    def create_comparison_matrix(self, competitors: List[Dict]) -> Dict:
        """Create competitive comparison matrix"""
        matrix = {
            'competitors': [c['name'] for c in competitors],
            'pricing': [c.get('pricing', 'Unknown') for c in competitors],
            'strengths': [', '.join(c.get('strengths', [])) for c in competitors],
            'weaknesses': [', '.join(c.get('weaknesses', [])) for c in competitors],
            'market_share': [c.get('market_share', 'Unknown') for c in competitors],
            'positioning': [c.get('positioning', 'Unknown') for c in competitors],
        }
        return matrix
    
    def identify_gaps(self, competitors: List[Dict]) -> List[str]:
        """Identify market opportunities and gaps"""
        gaps = []
        
        # Analyze common weaknesses
        all_weaknesses = []
        for comp in competitors:
            all_weaknesses.extend(comp.get('weaknesses', []))
        
        # Common pain points become opportunities
        weakness_counts = {}
        for weakness in all_weaknesses:
            key = weakness.lower()
            weakness_counts[key] = weakness_counts.get(key, 0) + 1
        
        # Find most common weaknesses
        common_weaknesses = sorted(weakness_counts.items(), key=lambda x: x[1], reverse=True)[:3]
        
        for weakness, count in common_weaknesses:
            if count >= 2:
                gaps.append(f"Address common pain point: {weakness} (found in {count} competitors)")
        
        # Add strategic gaps
        gaps.extend([
            'Focus on underserved customer segment',
            'Offer more transparent pricing model',
            'Provide better customer support experience',
            'Leverage emerging technologies (AI/ML)',
            'Build stronger community features',
        ])
        
        return gaps[:5]
