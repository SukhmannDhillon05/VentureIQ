"""
PDF Report Generator Module
Generates comprehensive validation reports
"""

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY
from reportlab.pdfgen import canvas
from datetime import datetime
from typing import Dict, List
import io

class ReportGenerator:
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles"""
        self.styles.add(ParagraphStyle(
            name='CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#1a1a1a'),
            spaceAfter=30,
            alignment=TA_CENTER,
        ))
        
        self.styles.add(ParagraphStyle(
            name='SectionHeading',
            parent=self.styles['Heading2'],
            fontSize=16,
            textColor=colors.HexColor('#2c3e50'),
            spaceAfter=12,
            spaceBefore=20,
        ))
        
        self.styles.add(ParagraphStyle(
            name='SubHeading',
            parent=self.styles['Heading3'],
            fontSize=13,
            textColor=colors.HexColor('#34495e'),
            spaceAfter=8,
            spaceBefore=12,
        ))
        
        self.styles.add(ParagraphStyle(
            name='BodyText',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#333333'),
            alignment=TA_JUSTIFY,
            spaceAfter=10,
        ))
        
        self.styles.add(ParagraphStyle(
            name='ScoreText',
            parent=self.styles['Normal'],
            fontSize=36,
            textColor=colors.HexColor('#27ae60'),
            alignment=TA_CENTER,
            spaceAfter=10,
        ))
    
    def generate_report(self, validation_data: Dict, output_path: str = "validation_report.pdf"):
        """Generate comprehensive PDF report"""
        
        doc = SimpleDocTemplate(
            output_path,
            pagesize=letter,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=48,
        )
        
        story = []
        
        # Cover Page
        story.extend(self._create_cover_page(validation_data))
        story.append(PageBreak())
        
        # Executive Summary
        story.extend(self._create_executive_summary(validation_data))
        story.append(PageBreak())
        
        # Market Analysis
        story.extend(self._create_market_analysis(validation_data))
        story.append(PageBreak())
        
        # Competitor Analysis (Most Detailed)
        story.extend(self._create_competitor_analysis(validation_data))
        story.append(PageBreak())
        
        # Financial Projections
        story.extend(self._create_financial_section(validation_data))
        story.append(PageBreak())
        
        # Success Prediction
        story.extend(self._create_success_section(validation_data))
        story.append(PageBreak())
        
        # Recommendations
        story.extend(self._create_recommendations(validation_data))
        
        # Build PDF
        doc.build(story)
        
        return output_path
    
    def _create_cover_page(self, data: Dict) -> List:
        """Create cover page"""
        elements = []
        
        elements.append(Spacer(1, 2*inch))
        elements.append(Paragraph("VentureIQ", self.styles['CustomTitle']))
        elements.append(Paragraph("Business Idea Validation Report", self.styles['Heading2']))
        elements.append(Spacer(1, 0.5*inch))
        
        idea = data['parsed_idea']
        elements.append(Paragraph(f"<b>Industry:</b> {idea['industry'].title()}", self.styles['BodyText']))
        elements.append(Paragraph(f"<b>Business Model:</b> {idea['business_model'].title()}", self.styles['BodyText']))
        elements.append(Spacer(1, 0.3*inch))
        
        # Success Score
        score = data['success_prediction']['overall_score']
        elements.append(Paragraph(f"{score}%", self.styles['ScoreText']))
        elements.append(Paragraph("Success Probability", self.styles['Heading3']))
        
        elements.append(Spacer(1, 1*inch))
        elements.append(Paragraph(f"Generated: {datetime.now().strftime('%B %d, %Y')}", self.styles['Normal']))
        
        return elements
    
    def _create_executive_summary(self, data: Dict) -> List:
        """Create executive summary section"""
        elements = []
        
        elements.append(Paragraph("Executive Summary", self.styles['SectionHeading']))
        elements.append(Spacer(1, 0.2*inch))
        
        idea = data['parsed_idea']
        market = data['market_research']
        success = data['success_prediction']
        
        # Overview
        elements.append(Paragraph("<b>Business Concept</b>", self.styles['SubHeading']))
        elements.append(Paragraph(idea['solution'], self.styles['BodyText']))
        
        # Key Highlights
        elements.append(Paragraph("<b>Key Highlights</b>", self.styles['SubHeading']))
        highlights = [
            f"Target Market: {idea['target_customer']}",
            f"Industry: {idea['industry'].title()} ({market['growth_rate']} growth)",
            f"Market Size: {market['niche_market_size']}",
            f"Competitors Identified: {len(data['competitors'])}",
            f"Success Score: {success['overall_score']}% ({success['confidence_level']} confidence)",
        ]
        
        for highlight in highlights:
            elements.append(Paragraph(f"• {highlight}", self.styles['BodyText']))
        
        # Quick Assessment
        elements.append(Spacer(1, 0.2*inch))
        elements.append(Paragraph("<b>Assessment</b>", self.styles['SubHeading']))
        recommendation = success.get('recommendation', data.get('recommendation', {}))
        elements.append(Paragraph(
            f"<b>{recommendation.get('verdict', 'ANALYZE')}:</b> {recommendation.get('message', 'Requires further analysis')}",
            self.styles['BodyText']
        ))
        
        return elements
    
    def _create_market_analysis(self, data: Dict) -> List:
        """Create market analysis section"""
        elements = []
        
        elements.append(Paragraph("Market Analysis", self.styles['SectionHeading']))
        elements.append(Spacer(1, 0.2*inch))
        
        market = data['market_research']
        
        # Market Size
        elements.append(Paragraph("<b>Market Size & Growth</b>", self.styles['SubHeading']))
        market_data = [
            ['Metric', 'Value'],
            ['Total Market Size', market['total_market_size']],
            ['Niche Market Size', market['niche_market_size']],
            ['Growth Rate', market['growth_rate']],
            ['Market Maturity', market['market_maturity']],
        ]
        
        table = Table(market_data, colWidths=[3*inch, 3*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#3498db')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 11),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTSIZE', (0, 1), (-1, -1), 10),
            ('TOPPADDING', (0, 1), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 8),
        ]))
        elements.append(table)
        
        # Industry Trends
        elements.append(Spacer(1, 0.2*inch))
        elements.append(Paragraph("<b>Key Industry Trends</b>", self.styles['SubHeading']))
        for trend in market['trends'][:5]:
            elements.append(Paragraph(f"• {trend}", self.styles['BodyText']))
        
        # Customer Needs
        elements.append(Spacer(1, 0.2*inch))
        elements.append(Paragraph("<b>Customer Needs</b>", self.styles['SubHeading']))
        for need in market['customer_needs'][:5]:
            elements.append(Paragraph(f"• {need}", self.styles['BodyText']))
        
        # Entry Barriers
        elements.append(Spacer(1, 0.2*inch))
        elements.append(Paragraph("<b>Entry Barriers</b>", self.styles['SubHeading']))
        for barrier in market['entry_barriers']:
            elements.append(Paragraph(f"• {barrier}", self.styles['BodyText']))
        
        return elements
    
    def _create_competitor_analysis(self, data: Dict) -> List:
        """Create detailed competitor analysis section"""
        elements = []
        
        elements.append(Paragraph("Competitive Landscape", self.styles['SectionHeading']))
        elements.append(Spacer(1, 0.2*inch))
        
        competitors = data['competitors']
        
        # Overview
        elements.append(Paragraph(
            f"Analysis of {len(competitors)} key competitors in the {data['parsed_idea']['industry']} space:",
            self.styles['BodyText']
        ))
        elements.append(Spacer(1, 0.15*inch))
        
        # Detailed Competitor Profiles
        for i, comp in enumerate(competitors, 1):
            elements.append(Paragraph(f"<b>{i}. {comp['name']}</b>", self.styles['SubHeading']))
            
            # Competitor details table
            comp_data = [
                ['Website', comp.get('website', 'N/A')],
                ['Founded', str(comp.get('year_founded', 'N/A'))],
                ['Positioning', comp.get('positioning', 'N/A')],
                ['Pricing', comp.get('pricing', 'N/A')],
                ['Market Share', comp.get('market_share', 'N/A')],
                ['Funding', comp.get('funding', 'N/A')],
            ]
            
            table = Table(comp_data, colWidths=[1.5*inch, 4.5*inch])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#ecf0f1')),
                ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 9),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ]))
            elements.append(table)
            
            # Strengths & Weaknesses
            elements.append(Spacer(1, 0.1*inch))
            strengths = comp.get('strengths', [])
            weaknesses = comp.get('weaknesses', [])
            
            if strengths:
                elements.append(Paragraph("<b>Strengths:</b>", self.styles['Normal']))
                for strength in strengths:
                    elements.append(Paragraph(f"  • {strength}", self.styles['BodyText']))
            
            if weaknesses:
                elements.append(Paragraph("<b>Weaknesses:</b>", self.styles['Normal']))
                for weakness in weaknesses:
                    elements.append(Paragraph(f"  • {weakness}", self.styles['BodyText']))
            
            elements.append(Spacer(1, 0.15*inch))
        
        # Market Gaps
        elements.append(PageBreak())
        elements.append(Paragraph("Market Opportunities", self.styles['SectionHeading']))
        elements.append(Paragraph(
            "Based on competitive analysis, the following gaps and opportunities were identified:",
            self.styles['BodyText']
        ))
        elements.append(Spacer(1, 0.1*inch))
        
        gaps = data.get('market_gaps', [])
        for gap in gaps:
            elements.append(Paragraph(f"• {gap}", self.styles['BodyText']))
        
        return elements
    
    def _create_financial_section(self, data: Dict) -> List:
        """Create financial projections section"""
        elements = []
        
        elements.append(Paragraph("Financial Projections", self.styles['SectionHeading']))
        elements.append(Spacer(1, 0.2*inch))
        
        financial = data.get('financial_model', {})
        assumptions = financial.get('assumptions', {})
        metrics = financial.get('metrics', {})
        
        # Assumptions
        elements.append(Paragraph("<b>Key Assumptions</b>", self.styles['SubHeading']))
        
        # Format assumptions table
        assumption_data = [['Parameter', 'Value']]
        for key, value in list(assumptions.items())[:8]:
            formatted_key = key.replace('_', ' ').title()
            if isinstance(value, float):
                formatted_value = f"{value:.1f}"
            else:
                formatted_value = str(value)
            assumption_data.append([formatted_key, formatted_value])
        
        table = Table(assumption_data, colWidths=[3*inch, 2*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2ecc71')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('BACKGROUND', (0, 1), (-1, -1), colors.lightgrey),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ]))
        elements.append(table)
        
        # 3-Year Summary
        elements.append(Spacer(1, 0.2*inch))
        elements.append(Paragraph("<b>3-Year Revenue Projections</b>", self.styles['SubHeading']))
        
        summary_data = [
            ['Year', 'Revenue', 'Growth'],
            ['Year 1', f"${metrics.get('year1_revenue', 0):,.0f}", '-'],
            ['Year 2', f"${metrics.get('year2_revenue', 0):,.0f}", f"{metrics.get('yoy_growth_y2', 0):.1f}%"],
            ['Year 3', f"${metrics.get('year3_revenue', 0):,.0f}", f"{metrics.get('yoy_growth_y3', 0):.1f}%"],
        ]
        
        table = Table(summary_data, colWidths=[1.5*inch, 2*inch, 1.5*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#3498db')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 11),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('BACKGROUND', (0, 1), (-1, -1), colors.lightblue),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ]))
        elements.append(table)
        
        # Key Metrics
        elements.append(Spacer(1, 0.2*inch))
        elements.append(Paragraph("<b>Key Financial Metrics</b>", self.styles['SubHeading']))
        
        metrics_data = [
            ['Total 3-Year Revenue', f"${metrics.get('total_revenue_3y', 0):,.0f}"],
            ['Total 3-Year Profit', f"${metrics.get('total_profit_3y', 0):,.0f}"],
            ['Gross Margin', f"{metrics.get('gross_margin_pct', 0):.1f}%"],
            ['Net Margin', f"{metrics.get('net_margin_pct', 0):.1f}%"],
            ['Break-even Month', str(metrics.get('breakeven_month', 'Not reached'))],
            ['Avg Monthly Revenue', f"${metrics.get('avg_monthly_revenue', 0):,.0f}"],
        ]
        
        for metric in metrics_data:
            elements.append(Paragraph(f"• <b>{metric[0]}:</b> {metric[1]}", self.styles['BodyText']))
        
        return elements
    
    def _create_success_section(self, data: Dict) -> List:
        """Create success prediction section"""
        elements = []
        
        elements.append(Paragraph("Success Prediction Analysis", self.styles['SectionHeading']))
        elements.append(Spacer(1, 0.2*inch))
        
        success = data['success_prediction']
        
        # Overall Score
        score = success['overall_score']
        elements.append(Paragraph(f"Overall Success Score: {score}%", self.styles['SubHeading']))
        elements.append(Paragraph(
            f"Confidence Level: {success['confidence_level']}",
            self.styles['BodyText']
        ))
        elements.append(Spacer(1, 0.15*inch))
        
        # Component Scores
        elements.append(Paragraph("<b>Score Components</b>", self.styles['SubHeading']))
        
        components = success['component_scores']
        comp_data = [['Factor', 'Score']]
        for key, value in components.items():
            formatted_key = key.replace('_', ' ').title()
            comp_data.append([formatted_key, f"{value}%"])
        
        table = Table(comp_data, colWidths=[3.5*inch, 1.5*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#9b59b6')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (0, -1), 'LEFT'),
            ('ALIGN', (1, 0), (1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('BACKGROUND', (0, 1), (-1, -1), colors.lavender),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ]))
        elements.append(table)
        
        # Reasoning
        elements.append(Spacer(1, 0.2*inch))
        elements.append(Paragraph("<b>Analysis</b>", self.styles['SubHeading']))
        for reason in success['reasoning']:
            elements.append(Paragraph(f"• {reason}", self.styles['BodyText']))
        
        # Risk Factors
        elements.append(Spacer(1, 0.15*inch))
        elements.append(Paragraph("<b>Risk Factors</b>", self.styles['SubHeading']))
        for risk in success['risk_factors']:
            elements.append(Paragraph(f"• {risk}", self.styles['BodyText']))
        
        # Success Factors
        elements.append(Spacer(1, 0.15*inch))
        elements.append(Paragraph("<b>Success Factors</b>", self.styles['SubHeading']))
        for factor in success['success_factors']:
            elements.append(Paragraph(f"• {factor}", self.styles['BodyText']))
        
        return elements
    
    def _create_recommendations(self, data: Dict) -> List:
        """Create recommendations section"""
        elements = []
        
        elements.append(Paragraph("Recommendations", self.styles['SectionHeading']))
        elements.append(Spacer(1, 0.2*inch))
        
        recommendation = data.get('recommendation', {})
        
        # Verdict
        elements.append(Paragraph(
            f"<b>Verdict: {recommendation.get('verdict', 'ANALYZE')}</b>",
            self.styles['SubHeading']
        ))
        elements.append(Paragraph(
            recommendation.get('message', 'Further analysis recommended'),
            self.styles['BodyText']
        ))
        
        # Next Steps
        elements.append(Spacer(1, 0.2*inch))
        elements.append(Paragraph("<b>Recommended Next Steps</b>", self.styles['SubHeading']))
        
        next_steps = recommendation.get('next_steps', [])
        for i, step in enumerate(next_steps, 1):
            elements.append(Paragraph(f"{i}. {step}", self.styles['BodyText']))
        
        # Closing
        elements.append(Spacer(1, 0.3*inch))
        elements.append(Paragraph(
            "<i>This report was generated by VentureIQ, an AI-powered business idea validation platform. "
            "All projections and scores are estimates based on available data and should be validated "
            "through additional market research and customer interviews.</i>",
            self.styles['BodyText']
        ))
        
        return elements
