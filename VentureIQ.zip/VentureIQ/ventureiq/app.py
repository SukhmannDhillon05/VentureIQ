"""
VentureIQ - AI Business Idea Validator
Main Streamlit Application
"""

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from datetime import datetime
import time
import os

# Import custom modules
from idea_parser import IdeaParser
from competitor_intelligence import CompetitorIntelligence
from market_research import MarketResearcher
from success_predictor import SuccessPredictor
from financial_model import FinancialModeler
from report_generator import ReportGenerator

# Page configuration
st.set_page_config(
    page_title="VentureIQ - AI Business Idea Validator",
    page_icon="💡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for animations and styling
st.markdown("""
<style>
    /* Hero section animation */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    @keyframes pulse {
        0%, 100% {
            opacity: 1;
        }
        50% {
            opacity: 0.5;
        }
    }
    
    .hero-title {
        font-size: 3.5rem;
        font-weight: 800;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
        animation: fadeInUp 0.8s ease-out;
        margin-bottom: 1rem;
    }
    
    .hero-subtitle {
        font-size: 1.5rem;
        color: #6b7280;
        text-align: center;
        animation: fadeInUp 1s ease-out;
        margin-bottom: 2rem;
    }
    
    .feature-card {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        padding: 1.5rem;
        border-radius: 1rem;
        margin: 1rem 0;
        animation: fadeInUp 1.2s ease-out;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    .score-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 2rem;
        border-radius: 1rem;
        text-align: center;
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    }
    
    .score-number {
        font-size: 4rem;
        font-weight: 800;
        margin: 1rem 0;
    }
    
    .progress-text {
        font-size: 1.2rem;
        color: #4f46e5;
        font-weight: 600;
        animation: pulse 1.5s ease-in-out infinite;
    }
    
    .competitor-card {
        border-left: 4px solid #667eea;
        padding: 1rem;
        margin: 0.5rem 0;
        background: #f9fafb;
        border-radius: 0.5rem;
    }
    
    .metric-box {
        background: white;
        padding: 1.5rem;
        border-radius: 0.75rem;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        border-top: 3px solid #667eea;
    }
    
    /* Tabs styling */
    .stTabs [data-baseweb="tab-list"] {
        gap: 2rem;
    }
    
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        padding: 0 2rem;
        font-size: 1.1rem;
    }
    
    /* Button styling */
    .stButton > button {
        width: 100%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        font-size: 1.1rem;
        font-weight: 600;
        padding: 0.75rem 2rem;
        border-radius: 0.5rem;
        border: none;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        transition: all 0.3s;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 12px rgba(0,0,0,0.15);
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'analysis_complete' not in st.session_state:
    st.session_state.analysis_complete = False
if 'validation_data' not in st.session_state:
    st.session_state.validation_data = None

def show_hero_section():
    """Display engaging hero section"""
    st.markdown('<h1 class="hero-title">💡 VentureIQ</h1>', unsafe_allow_html=True)
    st.markdown('<p class="hero-subtitle">AI-Powered Business Idea Validation Platform</p>', unsafe_allow_html=True)
    
    # Feature highlights
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown("""
        <div class="feature-card">
            <div style="font-size: 2rem; text-align: center;">🎯</div>
            <h4 style="text-align: center;">Idea Analysis</h4>
            <p style="text-align: center; font-size: 0.9rem;">Extract key insights from your idea</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="feature-card">
            <div style="font-size: 2rem; text-align: center;">🔍</div>
            <h4 style="text-align: center;">Competitor Intel</h4>
            <p style="text-align: center; font-size: 0.9rem;">Deep competitive analysis</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div class="feature-card">
            <div style="font-size: 2rem; text-align: center;">📊</div>
            <h4 style="text-align: center;">Market Research</h4>
            <p style="text-align: center; font-size: 0.9rem;">Industry trends & opportunities</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown("""
        <div class="feature-card">
            <div style="font-size: 2rem; text-align: center;">💰</div>
            <h4 style="text-align: center;">Financial Model</h4>
            <p style="text-align: center; font-size: 0.9rem;">3-year revenue projections</p>
        </div>
        """, unsafe_allow_html=True)

def show_input_form():
    """Multi-step input form for business idea"""
    st.markdown("## 📝 Describe Your Business Idea")
    st.markdown("Provide details about your business concept for comprehensive validation")
    
    with st.form("idea_form"):
        idea_text = st.text_area(
            "Business Idea Description",
            placeholder="Example: A mobile app for busy professionals that uses AI to create personalized meal plans and automatically orders groceries for delivery. We solve the problem of healthy eating being time-consuming. Target customers are working professionals aged 25-45 who value health but lack time. Subscription model at $29/month with features including AI meal planning, grocery auto-ordering, and nutrition tracking.",
            height=200,
            help="Describe your idea, target customers, problem solved, and business model"
        )
        
        col1, col2 = st.columns(2)
        
        with col1:
            industry_hint = st.selectbox(
                "Industry Category (Optional)",
                ["Auto-detect", "HealthTech", "FinTech", "EdTech", "Fashion-Tech", "FoodTech", 
                 "PropTech", "HR Tech", "MarTech", "SaaS", "E-commerce", "Other"],
                help="Help us better classify your industry"
            )
        
        with col2:
            num_competitors = st.slider(
                "Number of Competitors to Analyze",
                min_value=3,
                max_value=10,
                value=7,
                help="More competitors = more comprehensive analysis"
            )
        
        submitted = st.form_submit_button("🚀 Analyze My Idea", use_container_width=True)
        
        if submitted:
            if not idea_text or len(idea_text) < 50:
                st.error("❌ Please provide a more detailed description of your business idea (at least 50 characters)")
            else:
                return idea_text, industry_hint, num_competitors
    
    return None, None, None

def show_loading_animation(stage, message):
    """Display immersive loading animation"""
    progress_placeholder = st.empty()
    
    with progress_placeholder.container():
        st.markdown(f'<p class="progress-text">⚡ {message}</p>', unsafe_allow_html=True)
        progress_bar = st.progress(0)
        
        # Simulate progress
        for i in range(100):
            progress_bar.progress(i + 1)
            time.sleep(0.02)
        
        st.success(f"✅ {stage} Complete!")
        time.sleep(0.5)
    
    progress_placeholder.empty()

def run_analysis(idea_text, industry_hint, num_competitors):
    """Run comprehensive business idea analysis"""
    
    # Initialize modules
    parser = IdeaParser()
    competitor_intel = CompetitorIntelligence()
    market_researcher = MarketResearcher()
    success_predictor = SuccessPredictor()
    financial_modeler = FinancialModeler()
    
    # Stage 1: Parse Idea
    show_loading_animation("Idea Parsing", "Extracting key components from your idea...")
    parsed_idea = parser.parse(idea_text)
    
    # Override industry if hint provided
    if industry_hint != "Auto-detect":
        parsed_idea['industry'] = industry_hint.lower().replace(' ', '-')
    
    # Stage 2: Competitor Intelligence
    show_loading_animation("Competitor Intelligence", f"Finding and analyzing {num_competitors} competitors...")
    competitors = competitor_intel.find_competitors(
        parsed_idea['industry'],
        parsed_idea['solution'],
        num_competitors
    )
    comparison_matrix = competitor_intel.create_comparison_matrix(competitors)
    market_gaps = competitor_intel.identify_gaps(competitors)
    
    # Stage 3: Market Research
    show_loading_animation("Market Research", "Researching market size, trends, and opportunities...")
    market_data = market_researcher.research_market(
        parsed_idea['industry'],
        parsed_idea['target_customer']
    )
    
    # Stage 4: Financial Modeling
    show_loading_animation("Financial Modeling", "Creating 3-year financial projections...")
    financial_model = financial_modeler.create_model(
        parsed_idea['business_model'],
        parsed_idea['industry']
    )
    
    # Stage 5: Success Prediction
    show_loading_animation("Success Prediction", "Calculating success probability score...")
    success_prediction = success_predictor.predict_success(
        parsed_idea,
        market_data,
        competitors,
        data_quality=0.85
    )
    
    # Get recommendation
    recommendation = success_predictor.get_recommendation(success_prediction['overall_score'])
    
    # Compile all data
    validation_data = {
        'parsed_idea': parsed_idea,
        'competitors': competitors,
        'comparison_matrix': comparison_matrix,
        'market_gaps': market_gaps,
        'market_research': market_data,
        'financial_model': financial_model,
        'success_prediction': success_prediction,
        'recommendation': recommendation,
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    
    return validation_data

def show_results_dashboard(data):
    """Display comprehensive results dashboard with tabs"""
    
    # Success Score Header
    score = data['success_prediction']['overall_score']
    verdict = data['recommendation']['verdict']
    
    col1, col2, col3 = st.columns([2, 3, 2])
    
    with col2:
        st.markdown(f"""
        <div class="score-card">
            <h2 style="margin: 0;">Success Score</h2>
            <div class="score-number">{score}%</div>
            <h3 style="margin: 0;">{verdict}</h3>
            <p style="margin-top: 1rem; opacity: 0.9;">{data['recommendation']['message']}</p>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Tabbed Interface
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📊 Overview",
        "🔍 Competitors", 
        "📈 Market Analysis",
        "💰 Financials",
        "📄 Full Report"
    ])
    
    with tab1:
        show_overview_tab(data)
    
    with tab2:
        show_competitors_tab(data)
    
    with tab3:
        show_market_tab(data)
    
    with tab4:
        show_financials_tab(data)
    
    with tab5:
        show_report_tab(data)

def show_overview_tab(data):
    """Show overview with key insights"""
    st.markdown("## 📊 Executive Overview")
    
    idea = data['parsed_idea']
    success = data['success_prediction']
    
    # Key Details
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 🎯 Your Idea")
        st.markdown(f"**Industry:** {idea['industry'].title()}")
        st.markdown(f"**Target Customer:** {idea['target_customer']}")
        st.markdown(f"**Business Model:** {idea['business_model'].title()}")
        st.markdown(f"**Problem:** {idea['problem']}")
        
        if idea.get('key_features'):
            st.markdown("**Key Features:**")
            for feature in idea['key_features']:
                st.markdown(f"- {feature}")
    
    with col2:
        st.markdown("### 📈 Success Breakdown")
        
        # Component scores chart
        components = success['component_scores']
        fig = go.Figure(go.Bar(
            x=list(components.values()),
            y=[k.replace('_', ' ').title() for k in components.keys()],
            orientation='h',
            marker=dict(
                color=list(components.values()),
                colorscale='Viridis',
                showscale=False
            ),
            text=[f"{v}%" for v in components.values()],
            textposition='auto',
        ))
        
        fig.update_layout(
            title="Success Score Components",
            xaxis_title="Score",
            height=400,
            showlegend=False,
            plot_bgcolor='rgba(0,0,0,0)',
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    # Analysis & Recommendations
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### ✅ Success Factors")
        for factor in success['success_factors']:
            st.success(f"✓ {factor}")
    
    with col2:
        st.markdown("### ⚠️ Risk Factors")
        for risk in success['risk_factors']:
            st.warning(f"⚠ {risk}")
    
    # Next Steps
    st.markdown("---")
    st.markdown("### 🎯 Recommended Next Steps")
    
    for i, step in enumerate(data['recommendation']['next_steps'], 1):
        st.markdown(f"**{i}.** {step}")

def show_competitors_tab(data):
    """Show detailed competitor analysis"""
    st.markdown("## 🔍 Competitive Intelligence")
    
    competitors = data['competitors']
    
    st.markdown(f"### Found {len(competitors)} Key Competitors")
    
    # Competitor cards
    for i, comp in enumerate(competitors, 1):
        with st.expander(f"**{i}. {comp['name']}** - {comp.get('positioning', 'No positioning data')}", expanded=(i <= 3)):
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**📍 Basic Info**")
                st.markdown(f"- **Website:** {comp.get('website', 'N/A')}")
                st.markdown(f"- **Founded:** {comp.get('year_founded', 'N/A')}")
                st.markdown(f"- **Pricing:** {comp.get('pricing', 'N/A')}")
                st.markdown(f"- **Market Share:** {comp.get('market_share', 'N/A')}")
                st.markdown(f"- **Funding:** {comp.get('funding', 'N/A')}")
            
            with col2:
                st.markdown("**💪 Strengths**")
                for strength in comp.get('strengths', [])[:3]:
                    st.markdown(f"- {strength}")
                
                st.markdown("**⚡ Weaknesses**")
                for weakness in comp.get('weaknesses', [])[:3]:
                    st.markdown(f"- {weakness}")
    
    # Comparison Matrix
    st.markdown("---")
    st.markdown("### 📊 Competitive Comparison Matrix")
    
    matrix = data['comparison_matrix']
    df = pd.DataFrame({
        'Competitor': matrix['competitors'],
        'Pricing': matrix['pricing'],
        'Market Share': matrix['market_share'],
        'Key Strengths': [s[:50] + '...' if len(s) > 50 else s for s in matrix['strengths']],
    })
    
    st.dataframe(df, use_container_width=True, height=400)
    
    # Market Gaps
    st.markdown("---")
    st.markdown("### 🎯 Market Opportunities & Gaps")
    
    for gap in data['market_gaps']:
        st.info(f"💡 {gap}")

def show_market_tab(data):
    """Show market analysis"""
    st.markdown("## 📈 Market Analysis")
    
    market = data['market_research']
    
    # Market Size Metrics
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        <div class="metric-box">
            <h4>Total Market Size</h4>
            <h2 style="color: #667eea; margin: 0.5rem 0;">{}</h2>
        </div>
        """.format(market['total_market_size']), unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="metric-box">
            <h4>Your Niche Size</h4>
            <h2 style="color: #764ba2; margin: 0.5rem 0;">{}</h2>
        </div>
        """.format(market['niche_market_size'].split('(')[0]), unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div class="metric-box">
            <h4>Growth Rate</h4>
            <h2 style="color: #27ae60; margin: 0.5rem 0;">{}</h2>
        </div>
        """.format(market['growth_rate']), unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Trends and Needs
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 📊 Industry Trends")
        for trend in market['trends']:
            st.markdown(f"- **{trend}**")
    
    with col2:
        st.markdown("### 💡 Customer Needs")
        for need in market['customer_needs']:
            st.markdown(f"- {need}")
    
    # Additional Insights
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 🚧 Entry Barriers")
        for barrier in market['entry_barriers']:
            st.warning(f"⚠️ {barrier}")
    
    with col2:
        st.markdown("### 🎯 Pain Points")
        for pain in market['pain_points']:
            st.info(f"💭 {pain}")

def show_financials_tab(data):
    """Show financial projections with interactive sliders"""
    st.markdown("## 💰 Financial Projections")
    
    financial = data['financial_model']
    assumptions = financial['assumptions']
    metrics = financial['metrics']
    projections = financial['projections']
    
    # Key Metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Year 1 Revenue", f"${metrics['year1_revenue']:,.0f}")
    
    with col2:
        st.metric("Year 2 Revenue", f"${metrics['year2_revenue']:,.0f}", 
                 delta=f"{metrics['yoy_growth_y2']:.1f}%")
    
    with col3:
        st.metric("Year 3 Revenue", f"${metrics['year3_revenue']:,.0f}",
                 delta=f"{metrics['yoy_growth_y3']:.1f}%")
    
    with col4:
        st.metric("Break-even", f"Month {metrics['breakeven_month']}" if isinstance(metrics['breakeven_month'], int) else metrics['breakeven_month'])
    
    # Revenue Chart
    st.markdown("### 📈 3-Year Revenue Projection")
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=projections['month'],
        y=projections['revenue'],
        mode='lines',
        name='Revenue',
        line=dict(color='#667eea', width=3),
        fill='tonexty',
    ))
    
    fig.update_layout(
        title="Monthly Revenue Growth",
        xaxis_title="Month",
        yaxis_title="Revenue ($)",
        height=400,
        hovermode='x unified',
        plot_bgcolor='rgba(0,0,0,0)',
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Profit Chart
    st.markdown("### 💵 Profitability Analysis")
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=projections['month'],
        y=projections['revenue'],
        mode='lines',
        name='Revenue',
        line=dict(color='#27ae60', width=2),
    ))
    
    fig.add_trace(go.Scatter(
        x=projections['month'],
        y=projections['total_costs'],
        mode='lines',
        name='Costs',
        line=dict(color='#e74c3c', width=2),
    ))
    
    fig.add_trace(go.Scatter(
        x=projections['month'],
        y=projections['net_profit'],
        mode='lines',
        name='Net Profit',
        line=dict(color='#3498db', width=2),
    ))
    
    fig.update_layout(
        title="Revenue vs Costs vs Profit",
        xaxis_title="Month",
        yaxis_title="Amount ($)",
        height=400,
        hovermode='x unified',
        plot_bgcolor='rgba(0,0,0,0)',
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Assumptions & Scenario Planning
    st.markdown("---")
    st.markdown("### 🎛️ Key Assumptions")
    
    col1, col2 = st.columns(2)
    
    with col1:
        for key, value in list(assumptions.items())[:len(assumptions)//2]:
            formatted_key = key.replace('_', ' ').title()
            st.markdown(f"**{formatted_key}:** {value}")
    
    with col2:
        for key, value in list(assumptions.items())[len(assumptions)//2:]:
            formatted_key = key.replace('_', ' ').title()
            st.markdown(f"**{formatted_key}:** {value}")
    
    # Yearly Summary Table
    st.markdown("---")
    st.markdown("### 📊 Yearly Summary")
    
    yearly_df = pd.DataFrame({
        'Year': ['Year 1', 'Year 2', 'Year 3'],
        'Revenue': [f"${metrics['year1_revenue']:,.0f}", f"${metrics['year2_revenue']:,.0f}", f"${metrics['year3_revenue']:,.0f}"],
        'Growth': ['-', f"{metrics['yoy_growth_y2']:.1f}%", f"{metrics['yoy_growth_y3']:.1f}%"],
        'Gross Margin': [f"{metrics['gross_margin_pct']:.1f}%"] * 3,
        'Net Margin': [f"{metrics['net_margin_pct']:.1f}%"] * 3,
    })
    
    st.dataframe(yearly_df, use_container_width=True, hide_index=True)

def show_report_tab(data):
    """Show report generation options"""
    st.markdown("## 📄 Generate Full Report")
    
    st.markdown("""
    Generate a comprehensive 15-20 page PDF report including:
    - **Executive Summary** - Key findings and recommendations
    - **Market Analysis** - Detailed market research and trends
    - **Competitive Intelligence** - In-depth competitor profiles and gaps
    - **Financial Projections** - 3-year financial model with assumptions
    - **Success Analysis** - Component scores and risk factors
    - **Actionable Recommendations** - Next steps for your venture
    """)
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        if st.button("📥 Generate PDF Report", use_container_width=True):
            with st.spinner("Generating comprehensive report..."):
                try:
                    report_gen = ReportGenerator()
                    output_path = f"ventureiq_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
                    report_gen.generate_report(data, output_path)
                    
                    # Offer download
                    with open(output_path, 'rb') as f:
                        st.download_button(
                            label="⬇️ Download Report",
                            data=f,
                            file_name=output_path,
                            mime="application/pdf",
                            use_container_width=True
                        )
                    
                    st.success(f"✅ Report generated successfully: {output_path}")
                    
                except Exception as e:
                    st.error(f"❌ Error generating report: {str(e)}")
    
    # Preview key sections
    st.markdown("---")
    st.markdown("### 📋 Report Preview")
    
    preview_col1, preview_col2 = st.columns(2)
    
    with preview_col1:
        st.markdown("**Report Sections:**")
        st.markdown("""
        1. Cover Page
        2. Executive Summary
        3. Market Analysis
        4. Competitive Landscape (Most Detailed)
        5. Financial Projections
        6. Success Prediction
        7. Recommendations
        """)
    
    with preview_col2:
        st.markdown("**Key Insights:**")
        st.markdown(f"- {len(data['competitors'])} competitors analyzed")
        st.markdown(f"- {len(data['market_research']['trends'])} industry trends identified")
        st.markdown(f"- {len(data['market_gaps'])} market opportunities found")
        st.markdown(f"- 36-month financial projections")
        st.markdown(f"- {len(data['success_prediction']['risk_factors'])} risk factors assessed")

def main():
    """Main application flow"""
    
    # Sidebar
    with st.sidebar:
        st.image("https://api.dicebear.com/7.x/shapes/svg?seed=ventureiq", width=100)
        st.markdown("## VentureIQ")
        st.markdown("AI-powered business validation")
        st.markdown("---")
        
        if st.session_state.analysis_complete:
            if st.button("🔄 Analyze New Idea"):
                st.session_state.analysis_complete = False
                st.session_state.validation_data = None
                st.rerun()
        
        st.markdown("---")
        st.markdown("### About")
        st.markdown("""
        VentureIQ uses AI to analyze your business ideas across multiple dimensions:
        - Market analysis
        - Competitor intelligence  
        - Financial modeling
        - Success prediction
        """)
        
        st.markdown("---")
        st.markdown("© 2024 VentureIQ")
    
    # Main content
    if not st.session_state.analysis_complete:
        show_hero_section()
        st.markdown("---")
        
        idea_text, industry_hint, num_competitors = show_input_form()
        
        if idea_text:
            st.markdown("---")
            st.markdown("## ⚡ Running Analysis...")
            
            validation_data = run_analysis(idea_text, industry_hint, num_competitors)
            
            st.session_state.validation_data = validation_data
            st.session_state.analysis_complete = True
            
            st.balloons()
            time.sleep(1)
            st.rerun()
    
    else:
        show_results_dashboard(st.session_state.validation_data)

if __name__ == "__main__":
    main()
