"""
Idea Parser Module
Extracts structured data from natural language business idea descriptions
"""

import re
from typing import Dict, List, Optional

class IdeaParser:
    def __init__(self):
        self.industry_keywords = {
            'fashion-tech': ['fashion', 'clothing', 'apparel', 'wardrobe', 'style', 'outfit', 'boutique'],
            'healthtech': ['health', 'medical', 'fitness', 'wellness', 'healthcare', 'therapy', 'mental health', 'telemedicine'],
            'fintech': ['finance', 'payment', 'banking', 'investment', 'trading', 'crypto', 'blockchain', 'lending'],
            'edtech': ['education', 'learning', 'training', 'course', 'teaching', 'student', 'university', 'school'],
            'foodtech': ['food', 'restaurant', 'delivery', 'meal', 'recipe', 'cooking', 'grocery', 'nutrition'],
            'proptech': ['real estate', 'property', 'housing', 'rental', 'lease', 'apartment', 'home'],
            'hrtech': ['recruiting', 'hiring', 'hr', 'talent', 'employee', 'workforce', 'job'],
            'martech': ['marketing', 'advertising', 'analytics', 'seo', 'social media', 'campaign'],
            'logistics': ['delivery', 'shipping', 'logistics', 'supply chain', 'freight', 'warehouse'],
            'saas': ['software', 'platform', 'tool', 'app', 'application', 'dashboard', 'api'],
            'ecommerce': ['online store', 'marketplace', 'shop', 'retail', 'seller', 'product'],
            'social': ['social network', 'community', 'connect', 'share', 'messaging', 'dating'],
            'entertainment': ['gaming', 'video', 'streaming', 'music', 'content', 'media'],
            'productivity': ['productivity', 'workflow', 'collaboration', 'project management', 'task'],
        }
        
        self.business_model_keywords = {
            'subscription': ['subscription', 'monthly', 'recurring', 'membership', 'saas'],
            'marketplace': ['marketplace', 'platform', 'commission', 'connect', 'two-sided'],
            'ecommerce': ['sell products', 'online store', 'retail', 'inventory'],
            'freemium': ['free tier', 'freemium', 'premium', 'upgrade'],
            'advertising': ['advertising', 'ad-supported', 'free with ads'],
            'transaction': ['transaction fee', 'per transaction', 'commission'],
            'licensing': ['license', 'enterprise', 'per seat'],
        }
    
    def parse(self, idea_text: str) -> Dict:
        """Parse business idea text into structured components"""
        idea_lower = idea_text.lower()
        
        return {
            'raw_idea': idea_text,
            'industry': self._classify_industry(idea_lower),
            'target_customer': self._extract_target_customer(idea_text),
            'problem': self._extract_problem(idea_text),
            'solution': self._extract_solution(idea_text),
            'business_model': self._classify_business_model(idea_lower),
            'key_features': self._extract_features(idea_text),
        }
    
    def _classify_industry(self, text: str) -> str:
        """Classify industry based on keyword matching"""
        scores = {}
        for industry, keywords in self.industry_keywords.items():
            score = sum(1 for keyword in keywords if keyword in text)
            if score > 0:
                scores[industry] = score
        
        if scores:
            return max(scores, key=scores.get)
        return 'general-tech'
    
    def _extract_target_customer(self, text: str) -> str:
        """Extract target customer information"""
        # Look for patterns like "for X", "helping X", "serving X"
        patterns = [
            r'for ([a-z\s]+?)(?:\s+who|\s+that|\s+to|\.|,)',
            r'helping ([a-z\s]+?)(?:\s+who|\s+to|\.|,)',
            r'serving ([a-z\s]+?)(?:\s+who|\s+with|\.|,)',
            r'target(?:ing)?:?\s+([a-z\s]+?)(?:\.|,)',
        ]
        
        text_lower = text.lower()
        for pattern in patterns:
            match = re.search(pattern, text_lower)
            if match:
                customer = match.group(1).strip()
                if len(customer) > 3 and len(customer) < 100:
                    return customer.title()
        
        # Default based on industry context
        if 'business' in text_lower or 'company' in text_lower or 'enterprise' in text_lower:
            return 'Small to Medium Businesses'
        return 'General Consumers'
    
    def _extract_problem(self, text: str) -> str:
        """Extract problem statement"""
        patterns = [
            r'problem:?\s+([^.]+)',
            r'solves?\s+([^.]+)',
            r'addresses?\s+([^.]+)',
            r'pain point:?\s+([^.]+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1).strip()
        
        # Extract first sentence as problem if no explicit pattern
        sentences = re.split(r'[.!?]', text)
        if sentences:
            return sentences[0].strip()
        return 'Not explicitly stated'
    
    def _extract_solution(self, text: str) -> str:
        """Extract solution description"""
        patterns = [
            r'solution:?\s+([^.]+)',
            r'we (?:provide|offer|create|build)\s+([^.]+)',
            r'(?:platform|app|tool|service) (?:that|to)\s+([^.]+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1).strip()
        
        return text[:200] + '...' if len(text) > 200 else text
    
    def _classify_business_model(self, text: str) -> str:
        """Classify business model"""
        scores = {}
        for model, keywords in self.business_model_keywords.items():
            score = sum(1 for keyword in keywords if keyword in text)
            if score > 0:
                scores[model] = score
        
        if scores:
            return max(scores, key=scores.get)
        
        # Default based on industry
        if 'saas' in text or 'software' in text:
            return 'subscription'
        elif 'marketplace' in text or 'platform' in text:
            return 'marketplace'
        return 'subscription'
    
    def _extract_features(self, text: str) -> List[str]:
        """Extract key features"""
        features = []
        
        # Look for bullet points or numbered lists
        bullet_pattern = r'[•\-\*]\s*([^\n]+)'
        matches = re.findall(bullet_pattern, text)
        if matches:
            features.extend([m.strip() for m in matches])
        
        # Look for "features:" section
        feature_section = re.search(r'features?:([^.]+)', text, re.IGNORECASE)
        if feature_section:
            feature_text = feature_section.group(1)
            parts = re.split(r'[,;]', feature_text)
            features.extend([p.strip() for p in parts if p.strip()])
        
        return features[:5] if features else ['Core product/service delivery']
