CREATE TABLE `competitors` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`idea_id` integer NOT NULL,
	`name` text NOT NULL,
	`website` text,
	`pricing` text,
	`features` text,
	`positioning` text,
	`market_gap` text,
	`created_at` text NOT NULL,
	FOREIGN KEY (`idea_id`) REFERENCES `ideas`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `financial_projections` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`idea_id` integer NOT NULL,
	`assumptions` text NOT NULL,
	`year1_revenue` integer NOT NULL,
	`year2_revenue` integer NOT NULL,
	`year3_revenue` integer NOT NULL,
	`monthly_breakdown` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`idea_id`) REFERENCES `ideas`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `ideas` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`user_identifier` text NOT NULL,
	`title` text NOT NULL,
	`description` text NOT NULL,
	`industry` text NOT NULL,
	`target_customer` text NOT NULL,
	`problem` text NOT NULL,
	`solution` text NOT NULL,
	`business_model` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `market_research` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`idea_id` integer NOT NULL,
	`market_size` text NOT NULL,
	`industry_trends` text NOT NULL,
	`customer_needs` text NOT NULL,
	`entry_barriers` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`idea_id`) REFERENCES `ideas`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `validation_results` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`idea_id` integer NOT NULL,
	`success_score` integer NOT NULL,
	`market_score` integer NOT NULL,
	`competition_score` integer NOT NULL,
	`uniqueness_score` integer NOT NULL,
	`timing_score` integer NOT NULL,
	`reasoning` text NOT NULL,
	`data_quality` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`idea_id`) REFERENCES `ideas`(`id`) ON UPDATE no action ON DELETE no action
);
